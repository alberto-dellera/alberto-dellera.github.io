


drop table t;

create table t as select rownum-1 idx, rownum-1 d 
from dual connect by level <= 5;

select *
  from t
  model
    dimension by (idx, 0 step)
    measures (d)
    rules iterate(3) (
      d[any, step + 1] = previous (d[cv(),cv()-1])
    )
order by idx
;