091 STATEMENT 91 xsqlid='DELg7cysn0q0prj5' xbstmt=88 xs[f=929 l=950] hv=738909733 sqlid='g7cysn0q0prj5'

/* MV_REFRESH (DEL) */ DELETE 
  FROM "DELLERA"."TEST_MV" "SNA$" 
 WHERE ROWID IN (SELECT ROWID 
                   FROM ( SELECT ROW_NUMBER()              OVER (PARTITION BY "TEST_OUTER_ROWID" ORDER BY "TEST_INNER_ROWID" NULLS FIRST) R,  
                                 COUNT(*)                  OVER (PARTITION BY "TEST_OUTER_ROWID" ) T_CNT,  
                                 COUNT("TEST_INNER_ROWID") OVER (PARTITION BY "TEST_OUTER_ROWID" ) NONNULL_CNT  
                            FROM "DELLERA"."TEST_MV" "SNA2$" 
                           WHERE "TEST_OUTER_ROWID" IN (SELECT "MAS$1".ROWID  
                                                          FROM ( SELECT "MAS$"."ROWID" "RID$",  
                                                                        "MAS$".*  
                                                                   FROM "DELLERA"."TEST_INNER" "MAS$" 
                                                                  WHERE ROWID IN (SELECT  CHARTOROWID("MAS$"."M_ROW$$") RID$     
                                                                                    FROM "DELLERA"."MLOG$_TEST_INNER" "MAS$"   
                                                                                   WHERE "MAS$".SNAPTIME$$ > :B_ST0 
                                                                                 )
                                                               )  AS OF SNAPSHOT(:B_SCN)  "JV$", "TEST_OUTER" AS OF SNAPSHOT(:B_SCN)  "MAS$1" 
                                                         WHERE "MAS$1"."JOUTER"="JV$"."JINNER"
                                                       ) 
                        ) "SNA2$" 
                  WHERE T_CNT > 1  
                    AND ( (NONNULL_CNT = 0 AND R > 1) OR (NONNULL_CNT > 0 AND R <= T_CNT - NONNULL_CNT) ) 
                ) 
