define test_tag=overlapping_ranges_with_priority

alter session set nls_date_format='dd/mm/yyyy hh24:mi:ss';

variable db_version varchar2(30)
declare
  l_dummy varchar2(100);
begin
  dbms_utility.db_version (:db_version, l_dummy);
end;
/

col db_version new_value db_version
select replace ( rtrim(:db_version,'.0'), '.', '_') as db_version from dual;

set echo on

spool &test_tag._&db_version..lst

drop table ranges;

set echo on

create table ranges (
  sku   varchar2(10) not null,
  a     int not null,
  b     int not null,
  prio  int not null,
  price int not null
);

alter table ranges add constraint ranges_pk primary key (sku, a, b);

--insert into ranges(sku, a, b, prio, price) values ('sku1', ascii('a'), ascii('z'),    9, 100);
insert into ranges(sku, a, b, prio, price) values ('sku1', ascii('b'), ascii('d'),    0, 200);
insert into ranges(sku, a, b, prio, price) values ('sku1', ascii('c'), ascii('e'),    1, 300);
commit;

-- human-friendly range display function
create or replace function range_coded ( p_a int, p_b int, p_prio int, p_price int)
return varchar2
is
begin
  return 
    chr(p_a)
    ||'---'
    ||case when p_prio||p_price is not null then '(' end
    ||p_prio
    ||case when p_prio  is not null then ',' end
    ||case when p_price is not null then '$' end
    ||p_price
    ||case when p_prio||p_price is not null then ')' end 
    ||'---'
    ||chr(p_b);
end range_coded;
/

col sku form a4
col a form a2
col b form a2
col sa form a2
col sb form a2
col prio form 9999
col price form 9999
col range_coded form a24

select sku, chr(a) as a, chr(b) as b, prio, price, range_coded(a,b,prio,price) as range_coded from ranges order by sku, a, b;

-- the instants in time where the ranges start or begin
create or replace view 
instants as 
  select sku, a as i from ranges
  union
  select sku, b as i from ranges
; 

select sku, chr(i) from instants order by sku, i;

-- the base ranges, i.e. the consecutive ranges that connect all the instants 
create or replace view
base_ranges as
  select *
    from (
  select sku, 
         i as ba,
         lead(i) over (partition by sku order by i) as bb 
    from instants
         )
   where bb is not null 
; 

select sku, chr(ba) as a, chr(bb) as b, range_coded(ba,bb,null,null) as range_coded from base_ranges order by sku, ba, bb;

-- the original ranges factored over the base ranges; in other words, "cut" by the instants
create or replace view
factored_ranges as 
  select i.sku, bi.ba, bi.bb, i.a, i.b, i.prio, i.price
    from ranges i, base_ranges bi 
   where i.sku = bi.sku
     and (i.a <= bi.ba and bi.ba < i.b)  
;

select sku, chr(ba) as a, chr(bb) as b, prio, price, range_coded(ba,bb,prio,price) as range_coded from factored_ranges order by sku, ba, bb;

-- this filters out the factored ranges with lower priority (that have with an higher priority range "covering" them)
create or replace view
strongest_factored_ranges as 
  select sku, ba, bb, prio, price 
    from (
  select sku, ba, bb, prio, price,
         dense_rank () over (partition by sku, ba, bb order by prio) as rnk
    from factored_ranges
         )
   where rnk = 1
;

select sku, chr(ba) as a, chr(bb) as b, prio, price, range_coded(ba,bb,prio,price) as range_coded from strongest_factored_ranges order by sku, ba, bb;

-- "step" will be zero if a range can be joined to the previous one, since:
-- a) they are consecutive (no gap between them)
-- b) they have the same price
-- similar to http://www.oracle.com/technetwork/issue-archive/o24asktom-095715.html
create or replace view
ranges_with_step as 
  select sku, ba, bb, prio, price,
         decode ( price, lag(price) over (partition by sku order by ba),  ba - lag(bb) over (partition by sku order by ba), 1000 ) step
    from strongest_factored_ranges
;

select sku, chr(ba) as a, chr(bb) as b, price, range_coded(ba,bb,prio,price) as range_coded, step  from ranges_with_step order by sku, ba, bb;

-- the integral of step over the ranges
-- joinable ranges will hence have the same value for "interval" since step is zero
create or replace view
ranges_with_step_integral as 
  select sku, ba, bb, prio, price, step,
         sum(step) over (partition by sku order by ba rows between unbounded preceding and current row) as integral
    from ranges_with_step
;

select sku, chr(ba) as a, chr(bb) as b, price, range_coded(ba,bb,prio,price) as range_coded, integral from ranges_with_step_integral order by sku, ba, bb;

-- this joins the joinable ranges
create or replace view
ranges_joined as 
  select * 
    from (
  select sku, ba, bb, prio, price, step, integral,
         min(ba) over (partition by sku, integral) as a,
         max(bb) over (partition by sku, integral) as b
    from ranges_with_step_integral
         )
   where step > 0 
;

select sku, chr(ba) as a, chr(bb) as b, price, range_coded(ba,bb,prio,price) as range_coded from ranges_joined order by sku, ba, bb;

spool off

