/* MV_REFRESH (DEL) */ 
delete from test_mv where rowid in ( 
select rid 
  from ( 
select test_mv.rowid rid,  
       row_number() over (partition by test_outer_rowid order by rid$ nulls last) r,  
       count(*)     over (partition by test_outer_rowid ) t_cnt,  
       count(rid$)  over (partition by test_outer_rowid ) in_mvlog_cnt  
  from test_mv, (select distinct rid$ from mlog$_test_inner) mvlog 
 where /* read touched outer slices start */ 
       test_mv.test_outer_rowid in 
          ( 
          select test_outer_rowid 
            from test_mv 
           where test_inner_rowid in (select rid$ from mlog$_test_inner)
          ) 
       /* read touched outer slices end */ 
   and test_mv.test_inner_rowid = mvlog.rid$(+)                                       
       )  
 /* victim selection start */
 where t_cnt > 1  
   and ( (in_mvlog_cnt = t_cnt and r > 1) 
          or 
         (in_mvlog_cnt < t_cnt and r <= in_mvlog_cnt) 
       ) 
 /* victim selection end */
) 
        

