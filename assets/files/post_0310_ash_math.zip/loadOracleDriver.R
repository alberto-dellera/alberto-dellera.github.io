# Set JAVA_HOME, set max. memory, and load rJava library
#Sys.setenv(JAVA_HOME=paste( Sys.getenv("JAVA_HOME"),  'C:/Program Files/Java/jdk1.7.0_25', sep=":"));

options(java.parameters="-Xmx2g")
library(rJava)

# Output Java version
.jinit()
print( .jcall( "java/lang/System", "S", "getProperty", "java.version" ) )

# Load RJDBC library
library(RJDBC)

### Create connection driver and open connection
jdbcDriver <- JDBC(driverClass="oracle.jdbc.OracleDriver", classPath="C:/app/oracle/product/12.1.0/dbhome_3/jdbc/lib/ojdbc6.jar")
jdbcConnection <- dbConnect(jdbcDriver, "jdbc:oracle:thin:@//127.0.0.1:1522/ora12c", "dellera", "dellera")

### test connection 
instanceName <- dbGetQuery(jdbcConnection, "SELECT inst_id, instance_name FROM gv$instance")
print(instanceName)
##
### Close connection
##dbDisconnect(jdbcConnection)