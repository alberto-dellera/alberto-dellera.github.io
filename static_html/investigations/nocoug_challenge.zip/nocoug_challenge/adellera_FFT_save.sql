

-- F( p(i) ) (f) = sum [ i=0..num_frequencies-1, p(i) * exp (2 * PI * IMAG_UNIT * i * f / num_frequencies) ]

with base_constants as (
  select max (face_value) as max_face_value 
    from die 
    where probability != 0
), derived_constants as (
  select ceil ( log (2, max_face_value * :N + 1) ) as log_num_freq,
         max_face_value
    from base_constants
), constants as (
  select max_face_value          as max_s_1,
         max_face_value * :N     as max_s_N,
         log_num_freq,
         power (2, log_num_freq) as num_frequencies,
         3.14159265358979323846264338327950288419716939937510 as PI
    from derived_constants
), i_sequence as (
  select rownum-1 as i from dual connect by level <= (select num_frequencies from constants)
), /*base_frequencies as (
  select i, 
         - 2 * (select PI from constants ) * i / (select num_frequencies from constants) as base_frequency
    from i_sequence
),*/ p_s_1 as (
  select i as s, nvl (die.probability, 0) as probability
    from i_sequence, die
   where i_sequence.i = die.face_value(+)
     and die.probability(+) != 0
), dft_p_s_1 as (
  select *
    from (select s as f, probability as real, 0 as imag from p_s_1), (select rownum-1 as dummy from dual connect by level <= 3)
  model
    reference constants on (select 0 dummy, c.* from constants c)
      dimension by (dummy)
      measures (log_num_freq)
    reference butterfly on (select rownum-1 as iter, 
                                   power (2, log_num_freq - rownum) as width,
                                   power (2, rownum-1) as w_expon
                              from dual, (select log_num_freq from constants)
                            connect by level <= (select log_num_freq from constants) 
                           )
      dimension by (iter)
      measures (width, w_expon)
    reference W on (select rownum-1 as r,
                           cos ( -2 * PI * (rownum-1) / num_frequencies ) as real,
                           sin ( -2 * PI * (rownum-1) / num_frequencies ) as imag
                      from dual, (select PI, num_frequencies from constants)
                     connect by level <= (select num_frequencies from constants) 
                   )
      dimension by (r)
      measures (real, imag)
    main m
      dimension by (f, decode (dummy, 0, 'new', 1, 'old', 2, 'exp') oldnew )
      measures (real, imag, 0 aux_real, 0 aux_imag, 0 exp)
      rules sequential order 
      iterate (999999) until ( iteration_number+1 = constants.log_num_freq[0] ) (
        real[any, 'new'] = case when mod (trunc (cv(f) / butterfly.width[iteration_number]), 2) = 0
                                then + real[cv(), 'old'] + real[cv() + butterfly.width[iteration_number], 'old'] 
                                else - real[cv(), 'old'] + real[cv() - butterfly.width[iteration_number], 'old'] 
                           end,
        imag[any, 'new'] = case when mod (trunc (cv(f) / butterfly.width[iteration_number]), 2) = 0
                                then + imag[cv(), 'old'] + imag[cv() + butterfly.width[iteration_number], 'old'] 
                                else - imag[cv(), 'old'] + imag[cv() - butterfly.width[iteration_number], 'old'] 
                           end,
        real[any, 'exp'] = case when mod (trunc (cv(f) / butterfly.width[iteration_number]), 2) = 0
                                then 0
                                else mod (cv(f), butterfly.width[iteration_number]) 
                                   * butterfly.w_expon[iteration_number]
                           end,
        real[any, 'old'] = case when mod (trunc (cv(f) / butterfly.width[iteration_number]), 2) = 0 
                                then real[cv(), 'new']
                                else real[cv(), 'new'] * W.real[ real[cv(), 'exp'] ]
                                   - imag[cv(), 'new'] * W.imag[ real[cv(), 'exp'] ]
                           end,
        imag[any, 'old'] = case when mod (trunc (cv(f) / butterfly.width[iteration_number]), 2) = 0 
                                then imag[cv(), 'new']
                                else real[cv(), 'new'] * W.imag[ real[cv(), 'exp'] ]
                                   + imag[cv(), 'new'] * W.real[ real[cv(), 'exp'] ]
                           end
      )
)
select * from dft_p_s_1
 where oldnew = 'old'
order by reverse( to_bin(f)), oldnew desc;

