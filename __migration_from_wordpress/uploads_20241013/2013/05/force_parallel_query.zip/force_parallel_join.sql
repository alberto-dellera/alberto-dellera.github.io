define test_tag=force_parallel_join

-- prepare spooling
alter session set nls_date_format='dd/mm/yyyy hh24:mi:ss';

variable db_version varchar2(30)
declare
  l_dummy varchar2(100);
begin
  dbms_utility.db_version (:db_version, l_dummy);
end;                                                        
/

col db_version new_value db_version
select replace ( rtrim(:db_version,'.0'), '.', '_') as db_version from dual;

set echo on
set serveroutput on
set trimspool on
spool &test_tag._&db_version..lst

set echo on

drop table t;
drop table u;

create table t (x int not null, pad char(100 char) default 'x');

insert into t(x) select 0 from dual connect by level <= 10000;

create index t_idx on t(x);

exec dbms_stats.gather_table_stats (user, 'T', cascade=>true, estimate_percent=>null);

create table u (x int not null, pad char(100 char) default 'x');

insert into u(x) select x from t;

create index u_idx on u(x);

exec dbms_stats.gather_table_stats (user, 'U', cascade=>true, estimate_percent=>null);

alter system flush shared_pool;

alter session enable parallel query;

select /* serial */ sum(t.x+u.x) from t, u where t.x = u.x;

select /*+ parallel(t,20) parallel(u,20) */ sum(t.x+u.x) from t, u where t.x = u.x;

select /*+ parallel_index(t, t_idx, 20) parallel(t,20) parallel_index(u, u_idx, 20) parallel(u,20) */ sum(t.x+u.x) from t, u where t.x = u.x;

-- side note: check with parallel(N)
select /*+ parallel(20) */ sum(t.x+u.x) from t, u where t.x = u.x;

alter session force parallel query parallel 20;

select /* force parallel query */ sum(t.x+u.x) from t, u where t.x = u.x;

alter session force parallel query parallel 1;

@xplan "select % from t, u where t.x = u.x" "ti=bottom,oi=n"

spool off

host "rm &test_tag._&db_version._xplan.lst"
host "rename xplan_i1.lst &test_tag._&db_version._xplan.lst"






