source('loadOracleDriver.R')

library(ggplot2)
library(plyr)

distribution <- "UNIFORM;0;2e6"
#distribution <- "GAUSSIAN;1e6;4e5"
max_time_usec <- 1e11

dbSendUpdate( jdbcConnection, "begin dbms_random.seed(0); end;" )

events <- dbGetQuery( jdbcConnection, paste( sep="",
 "select * 
    from table( sim_pkg.events( '", distribution, "', 'CONSTANT;1e4',", max_time_usec, " ) ) 
   where session_state='WAITING'"))

dbSendUpdate( jdbcConnection, "begin dbms_random.seed(0); end;" )

samples <- dbGetQuery( jdbcConnection, paste( sep="",
"with bas as (
  select t.*, 1 as cnt 
  from table( sim_pkg.samples ( 
                cursor( select * from table( sim_pkg.events( '", distribution, "', 'CONSTANT;1e4', ", max_time_usec, "  ) ) )  
                ,
                1e90
            )
            ) t 
 where session_state = 'WAITING'
   and time_waited > 0 -- zeros are 'artificial samples' of the final 'true' sample when time_waited>=1sec
)
select * 
  from bas
 order by sample_id"))

events$time_waited_sec <- events$ELAPSED_USEC / 1e6
events$type <- "before sampling"

samples$time_waited_sec <- samples$TIME_WAITED / 1e6
samples$type <- "after sampling"

combined <- rbind( events[,c("time_waited_sec","type")], samples[,c("time_waited_sec","type")] )

combined$type <- factor(combined$type, levels=c("before sampling","after sampling"))

print_events <- function( events, x_label = NA ) {
  mu <- ddply(events, "type", summarise, grp.mean=mean(time_waited_sec))
  head(mu)

  palette <- c("gray","#0072B2")

  print( ggplot( data=events, aes( x=time_waited_sec, fill=type ) ) 
       + geom_vline( data=mu, aes( xintercept=grp.mean, color=type ), linetype="dashed", size=1, show.legend=FALSE )
       + geom_histogram( bins=20, boundary=0, position="dodge", color = "black" )
       + theme_bw()
       + scale_fill_manual ( values=palette )
       + scale_color_manual( values=palette )
       + labs( x=x_label )
  )
}

png("events.png")
print_events( events, "elapsed_sec" )
dev.off()

png("combined.png")
print_events( combined, "time_waited_sec" )
dev.off()

print_events( combined, "time_waited_sec" )

mean(samples$time_waited_sec)







