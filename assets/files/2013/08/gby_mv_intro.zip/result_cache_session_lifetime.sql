-- RESULT_CACHE(LIFETIME=SESSION)
-- 1) result is cached as normally, and available to other sesssions
--    as well, not only the current one 
--   (to reproduce in 11.2.0.3: just select from v on another session) 
-- 2) result is removed from cache as soon as original session expires
--
-- It is relevant for MVs because TMPDLT(mvlog) is scn-flashed-back, hence will
-- not be removed from the result cache when the mv log is modified.
-- Since the result of TMPDLT is no longer relevant as soon as the
-- MV has refreshed, this optimization ensures that when the session expires
-- it will be removed immediately, saving space in the cache 


alter session set nls_date_format='dd/mm/yyyy hh24:mi:ss';

variable db_version varchar2(30)
declare
  l_dummy varchar2(100);
begin
  dbms_utility.db_version (:db_version, l_dummy);
end;
/

col db_version new_value db_version
select replace ( rtrim(:db_version,'.0'), '.', '_') as db_version from dual;

set echo on

spool result_cache_session_lifetime_&db_version..lst

drop table t;

-- test table
create table t as select rownum-1 as x from dual connect by level <= 1000000;

-- wait a bit to prevent ORA-01466: "unable to read data - table definition has changed"
exec dbms_lock.sleep (10);

col curr_scn new_value curr_scn
select to_char(dbms_flashback.get_system_change_number) as curr_scn from dual;

-- create as-of-scn view, result cached
drop view v;
create or replace view v 
as
select /*+ RESULT_CACHE(LIFETIME=SESSION) */ 
       -- /*+ RESULT_CACHE */ 
       count(*) as cnt 
  from t as of scn &curr_scn.;

set autotrace on
-- this performs about 1500 consistent gets
select * from v;
set autotrace traceonly statistics
-- this performs about 32 consistent gets (result is cached)
select * from v;
set autotrace off
-- modify the base tables
delete from t where rownum=1;
commit;
-- this performs about 32 consistent gets again (result is STILL cached
-- because the view is scn-flashed-back)
set autotrace traceonly statistics
select * from v;
set autotrace off

-- just for fun
select name from v$result_cache_objects where status != 'Invalid' and type='Result';

spool off
