/* MV_REFRESH (UPD) */ 
update test_mv
   set jinner = null, xinner = null, pkinner = null, test_inner_rowid = null 
 where test_inner_rowid in (select rid$ from mlog$_test_inner)

    