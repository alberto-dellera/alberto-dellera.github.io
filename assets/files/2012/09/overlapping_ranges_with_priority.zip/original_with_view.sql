create or replace view ranges_output_view
as
-- the instants in time where the ranges start or begin
with instants as (
  select sku, a as i from ranges
  union
  select sku, b as i from ranges
), 
-- the base ranges, i.e. the consecutive ranges that connect all the instants 
base_ranges as (
  select *
    from (
  select sku, 
         i as ba,
         lead(i) over (partition by sku order by i) as bb 
    from instants
         )
   where bb is not null 
), 
-- the original ranges factored over the base ranges; in other words, "cut" by the instants
factored_ranges as (
  select i.sku, bi.ba, bi.bb, i.a, i.b, i.prio, i.price
    from ranges i, base_ranges bi 
   where i.sku = bi.sku
     and (i.a <= bi.ba and bi.ba < i.b)  
), 
-- this filters out the factored ranges with lower priority (that have with an higher priority range "covering" them)
strongest_factored_ranges as (
  select sku, ba, bb, prio, price 
    from (
  select sku, ba, bb, prio, price,
         dense_rank () over (partition by sku, ba, bb order by prio) as rnk
    from factored_ranges
         )
   where rnk = 1
), 
-- "step" will be zero if a ranges can be joined to the previous one, since:
-- a) they are consecutive (no gap between them)
-- b) they have the same price
-- similar to http://www.oracle.com/technetwork/issue-archive/o24asktom-095715.html
ranges_with_step as (
  select sku, ba, bb, prio, price,
         decode ( price, lag(price) over (partition by sku order by ba),  ba - lag(bb) over (partition by sku order by ba), 1000 ) step
    from strongest_factored_ranges
), 
-- the integral of step over the ranges
-- joinable ranges will hence have the same value for "interval" since step is zero
ranges_with_step_integral as (
  select sku, ba, bb, prio, price, step,
         sum(step) over (partition by sku order by ba rows between unbounded preceding and current row) as integral
    from ranges_with_step
), 
-- this joins the joinable ranges
ranges_joined as (
  select * 
    from (
  select sku, ba, bb, prio, price, step, integral,
         min(ba) over (partition by sku, integral) as a,
         max(bb) over (partition by sku, integral) as b
    from ranges_with_step_integral
         )
   where step > 0 
)
select sku, a, b, price from ranges_joined 
;
