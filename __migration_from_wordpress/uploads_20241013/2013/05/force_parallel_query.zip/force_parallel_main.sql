define test_tag=force_parallel_main

-- prepare spooling
alter session set nls_date_format='dd/mm/yyyy hh24:mi:ss';

variable db_version varchar2(30)
declare
  l_dummy varchar2(100);
begin
  dbms_utility.db_version (:db_version, l_dummy);
end;                                                        
/

col db_version new_value db_version
select replace ( rtrim(:db_version,'.0'), '.', '_') as db_version from dual;

set echo on
set serveroutput on
set trimspool on
spool &test_tag._&db_version..lst

set echo on

drop table t;

create table t (x int not null, pad char(100 char) default 'x');

insert into t(x) select 0 from dual connect by level <= 1000000;

create index t_idx on t(x);

exec dbms_stats.gather_table_stats (user, 'T', cascade=>true, estimate_percent=>null);

alter system flush shared_pool;

alter session enable parallel query;

select /* serial */ sum(x) from t;

select /*+ full(t) for getting fts cost only */ sum(x) from t;

select /*+ parallel(t,20) */ sum(x) from t;

select /*+ parallel_index(t, t_idx, 20) parallel(t,20) */ sum(x) from t;

-- side note: check with parallel(N)
select /*+ parallel(20) */ sum(x) from t;

alter session force parallel query parallel 20;

select /* force parallel query  */ sum(x) as from t;

select /* force parallel query (with no parallel execution) */ sum(x) as from t WHERE X < 0;

alter session force parallel query parallel 1;

@xplan "select %sum(x)% from t%" "ti=bottom,oi=n"

spool off

host "rm &test_tag._&db_version._xplan.lst"
host "rename xplan_i1.lst &test_tag._&db_version._xplan.lst"







