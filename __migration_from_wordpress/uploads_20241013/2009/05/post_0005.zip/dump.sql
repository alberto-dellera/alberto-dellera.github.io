column  header_block new_value m_block
column  header_file new_value m_file
define  m_offset=1

select  header_file, 
        header_block + &m_offset  header_block
from    dba_segments 
where   segment_name = upper('T_IDX')
and     owner = user
;

show parameter user_dump_dest
alter system dump datafile &m_file block min &m_block block max &m_block;

exit;

