

select * from die;

select *
  from die  
  model              
    reference r on ( select 0 dum, count(*) cnt from dual )
      dimension by (dum)
      measures (cnt) 
    reference r2 on ( select 0 dum2, count(*) cnt2 from dual )
      dimension by (dum2)
      measures (cnt2) 
    main m
    dimension by (face_value)
    measures (probability)
    rules (
      probability[9999] = r.cnt[0]
    );