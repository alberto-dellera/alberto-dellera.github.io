set echo on
set trimspool on
set verify off

spool ash_math_test.lst

alter session set plsql_code_type = 'NATIVE';
alter session set plsql_optimize_level = 2;

-- wait event type 
drop type wait_event_type_arr;

create or replace type wait_event_type as object (
  elapsed_usec    number,
  session_state   varchar2(7 char),
  wait_start_usec number,
  wait_end_usec   number
);
/
show errors

create or replace type wait_event_type_arr is table of wait_event_type;
/
show errors

-- sample type 
drop type sample_type_arr;

create or replace type sample_type as object (
  sample_id               int,
  sample_time             number,
  session_state           varchar2(7 char),
  time_waited             number,  
  events_tot_num          number,
  events_tot_elapsed_usec number
);
/
show errors

create or replace type sample_type_arr is table of sample_type;
/
show errors

create or replace package sim_pkg as 

------------------------------------------------------------------
function events ( p_pdf varchar2 default 'GAUSSIAN;10e3;3e3', p_pdf_cpu varchar2 default 'CONSTANT;10e3', p_max_time_usec number default null )
return wait_event_type_arr
pipelined;

------------------------------------------------------------------
function samples ( p_events_cursor sys_refcursor, p_num_samples_max int default null )
return sample_type_arr
pipelined;

end sim_pkg;
/
show errors

create or replace package body sim_pkg as 

type params_type is table of number index by binary_integer;

------------------------------------------------------------------
function next_event_time_usec( p_pdf_name varchar2, p_params params_type ) 
return number 
is 
  l_expected_average_usec number := 10e3;
  l_expected_stddev_usec  number := 7e3;
  l_wt number;
  l_min number;
  l_max number;
begin 
  if p_pdf_name = 'GAUSSIAN' then 
    l_expected_average_usec := p_params(0);
    l_expected_stddev_usec  := p_params(1);
    l_wt := l_expected_average_usec + dbms_random.normal * l_expected_stddev_usec;
  elsif p_pdf_name = 'UNIFORM' then 
    l_min := p_params(0);
    l_max := p_params(1);
    l_wt := dbms_random.value( l_min, l_max );
  elsif p_pdf_name = 'CONSTANT' then 
    l_wt := p_params(0);
  elsif p_pdf_name = 'ZERO' then 
    l_wt := 0;  
  else 
    raise_application_error ( -20001, 'invalid p_pdf_name="' || p_pdf_name || '"' );
  end if;

  return case when l_wt = 0 then 1 else abs( l_wt ) end;
end next_event_time_usec;

------------------------------------------------------------------
function extract_params ( p_pdf varchar2, p_pdf_name out varchar2 )
return params_type 
is 
  l_pdf varchar2(100 char) := p_pdf||';';
  l_params params_type;
  l_semi int;
  l_semi_next int;
  l_val varchar2(100 char);
  l_num int := 0;
  l_number number;
begin
  l_semi := instr( l_pdf, ';' ); 
  p_pdf_name := substr( l_pdf, 1, l_semi -1 );
  loop
    l_semi_next := instr( l_pdf, ';', l_semi + 1 );
    exit when l_semi_next = 0;
    l_val := substr( l_pdf, l_semi + 1, case when l_semi_next > 0 then l_semi_next - l_semi - 1 else length(l_pdf) end );
    begin 
      l_number := to_number( l_val );
    exception 
      when value_error then 
        raise_application_error( -20001, 'invalid number: "' || l_val||'"' );
    end;
    l_params(l_num) := l_number;
    l_num := l_num + 1;
    l_semi := l_semi_next;
  end loop;
  return l_params;
end extract_params;

------------------------------------------------------------------
-- Simulates a process that alternates between consuming CPU and waiting on an event.
-- The two Probability Density Functions desired can be passed in p_pdf and p_pdf_cpu.
-- It returns events in the time interval [0 .. p_max_time_usec]  
function events ( p_pdf varchar2 default 'GAUSSIAN;10e3;3e3', p_pdf_cpu varchar2 default 'CONSTANT;10e3', p_max_time_usec number default null )
return wait_event_type_arr
pipelined
is
  l_pdf_name     varchar2(100 char);
  l_pdf_name_cpu varchar2(100 char);
  l_params     params_type;
  l_params_cpu params_type;
  l_waited_usec number;
  l_current_time_usec number := 0;
  l_wait_start_usec number;
  l_wait_end_usec number;
  l_ev wait_event_type; 
begin 
  l_params     := extract_params( p_pdf     , l_pdf_name     );
  l_params_cpu := extract_params( p_pdf_cpu , l_pdf_name_cpu );
  loop 
    -- send back a wait event 
    l_wait_start_usec := l_current_time_usec;
    l_waited_usec := next_event_time_usec( l_pdf_name, l_params );
    l_current_time_usec := l_current_time_usec + l_waited_usec;
    l_wait_end_usec := l_current_time_usec;
    l_ev := wait_event_type ( l_waited_usec, 'WAITING', l_wait_start_usec, l_wait_end_usec );
    pipe row ( l_ev );
    -- send back a cpu event 
    l_wait_start_usec := l_current_time_usec;
    l_waited_usec := next_event_time_usec( l_pdf_name_cpu, l_params_cpu );
    l_current_time_usec := l_current_time_usec + l_waited_usec;
    l_wait_end_usec := l_current_time_usec;
    l_ev := wait_event_type ( l_waited_usec, 'ON CPU', l_wait_start_usec, l_wait_end_usec );
    pipe row ( l_ev );
    -- return if required time interval has elapsed
    if l_current_time_usec >= p_max_time_usec then 
      return;
    end if;
  end loop; 
end events;

------------------------------------------------------------------
-- Samples the event stream passed in "p_events_cursor" every second,
-- and stops when the cursor is empty or p_num_samples_max (if not null) samples have been returned.
function samples ( p_events_cursor sys_refcursor, p_num_samples_max int default null )
return sample_type_arr
pipelined
is
  type sample_arr_type is table of sample_type index by varchar2(7 char);
  l_sample_arr sample_arr_type;
  l_event wait_event_type := wait_event_type(0,0,0,0);
  l_sample_wallclock_start number := 0;
  l_sample_wallclock_stop  number := 0;
  l_next_sample_time number;
  l_num_sampled int := 0;
  l_sample_id   number := 0;
  l_sample_time number := 0;
  l_dummy1 number;
  l_dummy2 number;
begin 
  l_sample_arr('ON CPU' ) := sample_type( 0, 0, 'ON CPU' ,  0, 0, 0 );
  l_sample_arr('WAITING') := sample_type( 0, 0, 'WAITING',  0, 0, 0 );

  loop 
    -- read next event
    fetch p_events_cursor into l_event.elapsed_usec, l_event.session_state, l_dummy1, l_dummy2;
    exit when p_events_cursor%notfound;
    l_sample_wallclock_start := l_sample_wallclock_stop;
    l_sample_wallclock_stop  := l_sample_wallclock_stop + l_event.elapsed_usec;

    --dbms_output.put_line('got '||l_event.elapsed_usec||' '||l_event.session_state||' / '||l_sample_wallclock_start||' '||l_sample_wallclock_stop);

    -- remember event history so far
    l_sample_arr(l_event.session_state).events_tot_num          := l_sample_arr(l_event.session_state).events_tot_num + 1;
    l_sample_arr(l_event.session_state).events_tot_elapsed_usec := l_sample_arr(l_event.session_state).events_tot_elapsed_usec + l_event.elapsed_usec;

    while l_sample_time < l_sample_wallclock_stop loop
      -- return sample if inside event event wallclock interval
      if l_sample_wallclock_start <= l_sample_time then 
        l_sample_arr(l_event.session_state).sample_id   := l_sample_id;
        l_sample_arr(l_event.session_state).sample_time := l_sample_time;
        l_next_sample_time := l_sample_time + 1e6;
        l_sample_arr(l_event.session_state).time_waited := 
          case when l_event.session_state = 'ON CPU' then 0 
               when l_next_sample_time < l_sample_wallclock_stop then 0 
               else l_event.elapsed_usec
          end;
        pipe row ( l_sample_arr(l_event.session_state) );
        -- return if the desired number of samples has been returned
        if l_event.session_state = 'WAITING' then 
          l_num_sampled := l_num_sampled + 1;
          if l_num_sampled >= p_num_samples_max then 
            return;
          end if;
        end if;
        -- set next sample time data
        l_sample_id   := l_sample_id + 1;
        l_sample_time := l_sample_id * 1e6;
      end if;
    end loop;
  end loop;
end samples;

end sim_pkg;
/
show errors

--------------------------------- examples of observations of event stream and its samples
define pdf="'UNIFORM;0;5e6'"
define pdf_cpu="'CONSTANT;0.5e6'"
define max_time_usec=4e6
define seed=4
col session_state form a13
col elapsed_usec form 999,999,999.000
col time_waited  form 999,999,999.000
-- events
exec dbms_random.seed (&&seed. );
select session_state, elapsed_usec 
  from table( sim_pkg.events( &&pdf., &&pdf_cpu., &&max_time_usec. ) )
;

-- samples
exec dbms_random.seed( &&seed. );
select sample_id, sample_time, session_state, time_waited
  from table( sim_pkg.samples ( 
                cursor( select * from table( sim_pkg.events( &&pdf., &&pdf_cpu., &&max_time_usec. ) ) )  
              )
            ) t 
;

--------------------------------- histograms of observations of event stream and its samples
define pdf="'UNIFORM;0;2e6'"
define pdf_cpu="'CONSTANT;1e4'"
define max_time_usec=1e11

-- event stream histogram
exec dbms_random.seed(0);
col bar form a100
define bin_width=0.1e6
with bas as (
  select elapsed_usec from table( sim_pkg.events( &&pdf., &&pdf_cpu., &&max_time_usec. ) )
   where session_state = 'WAITING'
), h as (
  select round( elapsed_usec / &&bin_width. ) * &&bin_width. as bin, count(*) as cnt 
    from bas 
   group by round( elapsed_usec / &&bin_width. ) 
), h_max as (
  select max(cnt) as max_cnt, max( bin ) as max_bin
  from h 
), bin_points as (
  select &&bin_width. * (rownum-1) as bin from dual connect by level <= ( select round(max_bin/&&bin_width.) + 1 from h_max )
) 
select p.bin, rpad('*', round( 100 * nvl(h.cnt,0) / (select max_cnt from h_max ) ), '*' ) as bar
  from bin_points p, h
 where p.bin = h.bin(+)
 order by bin;

-- sampled stream histogram
exec dbms_random.seed(0);
with bas as (
  select t.*, 1 as cnt 
  from table( sim_pkg.samples ( 
                cursor( select * from table( sim_pkg.events( &&pdf., &&pdf_cpu., &&max_time_usec. ) ) )  
              )
            ) t 
 where session_state = 'WAITING'
   and time_waited > 0 -- zeros are 'artificial samples' of the final 'true' sample when time_waited >= 1sec
), h as (
  select round( time_waited / &&bin_width. ) * &&bin_width. as bin, count(*) as cnt 
    from bas 
   group by round( time_waited / &&bin_width. ) 
), h_max as (
  select max(cnt) as max_cnt, max( bin ) as max_bin 
  from h 
), bin_points as (
  select &&bin_width. * (rownum-1) as bin from dual connect by level <= ( select round(max_bin/&&bin_width.) + 1 from h_max )
) 
select /*+ no_parallel */ p.bin, rpad('*', round( 100 * nvl(h.cnt,0) / (select max_cnt from h_max ) ), '*' ) as bar
  from bin_points p, h
 where p.bin = h.bin(+)
 order by bin;

--------------------------------- formula check
-- expected value estimates
col elapsed_usec          form 999,999,999.000
col true_avg              form 999,999,999.000
col time_waited_math_usec form 999,999,999.000
exec dbms_random.seed(0);
with bas as (
  select t.*, 1 as cnt 
  from table( sim_pkg.samples ( 
                cursor( select * from table( sim_pkg.events( &&pdf., &&pdf_cpu., &&max_time_usec. ) ) )  
              )
            ) t 
  where session_state = 'WAITING'
), calc as (
  select avg(nullif(time_waited,0)) as time_waited_avg, -- (wrong) naive estimate simply discarding time_waited = 0
         max(events_tot_elapsed_usec) / max(events_tot_num) as true_avg,
         1e3 * (sum( 1000 * cnt ) 
                / nullif ( sum( greatest( 1, 1000000 * cnt / case when time_waited > 0 then time_waited end ) ), 0) 
               ) as time_waited_math_usec,
         sum( 1000 * cnt ) as numerator,
         nullif ( sum( greatest( 1, 1000000 * cnt / case when time_waited > 0 then time_waited end ) ), 0) as denominator, 
         count(*) as samples_num
    from bas
)
select time_waited_avg, true_avg, time_waited_math_usec, 
       round( 100*(time_waited_math_usec-true_avg)/true_avg, 2 ) as err_perc,
       numerator, denominator, samples_num
  from calc
;

spool off