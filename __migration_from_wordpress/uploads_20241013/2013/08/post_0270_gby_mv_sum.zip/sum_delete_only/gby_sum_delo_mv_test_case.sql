-- Materialized View Fast Refresh Restrictions and ORA-12052 [ID 222843.1]
-- mv logs:
-- Contain all columns from the table referenced in the materialized view. 
-- Specify with ROWID and INCLUDING NEW VALUES.
-- Specify the SEQUENCE clause if the table is expected to have a mix of inserts/direct-loads, deletes, and updates.

-- http://docs.oracle.com/cd/E11882_01/server.112/e25554/basicmv.htm#g1014280 table 9-2

drop materialized view test_mv;
drop table test_master;

alter session set nls_date_format='dd/mm/yyyy hh24:mi:ss';

variable db_version varchar2(30)
declare
  l_dummy varchar2(100);
begin
  dbms_utility.db_version (:db_version, l_dummy);
end;
/

col db_version new_value db_version
select replace ( rtrim(:db_version,'.0'), '.', '_') as db_version from dual;

set echo on

spool gby_sum_delo_mv_test_case_&db_version..lst

-- base table test_master
create table test_master (whe int, gby int, dat int, master_pk int constraint test_master_pk primary key);
insert into test_master (whe, gby, dat, master_pk) select 0, mod(rownum-1,2), 1, rownum from dual connect by level < 1000;
exec dbms_stats.gather_table_stats (user, 'test_master', cascade=>true, method_opt=>'for all columns size 1');
create materialized view log on test_master with rowid(whe,gby,dat), sequence including new values;
exec dbms_stats.gather_table_stats (user, 'mlog$_test_master', cascade=>true, method_opt=>'for all columns size 1', estimate_percent=>null);
exec dbms_stats.lock_table_stats(user, 'mlog$_test_master');

---- create group_by-only materialized view 
create materialized view test_mv
build immediate
refresh fast on demand
with rowid
as
select gby        as mv_gby, 
       count(*)   as mv_cnt_star,
       sum  (dat) as mv_sum_dat,
       count(dat) as mv_cnt_dat
  from test_master
 where whe = 0
 group by gby
;

-- create indexes on ..
exec dbms_stats.gather_table_stats (user, 'test_mv', cascade=>true, method_opt=>'for all columns size 1', estimate_percent=>null);

---- check mv is fast refreshable 
delete from mv_capabilities_table;

exec dbms_mview.explain_mview ( 'test_mv' ); 

set lines 150
col capability_name form a30
col related_text form a10
col msgtxt form a100

select capability_name, possible, related_text, msgtxt from mv_capabilities_table
 where mvowner = user and mvname = 'TEST_MV'
   and capability_name like 'REFRESH%'
 order by capability_name;
  
-- wait to differentiate timestamps
select sysdate as slightly_after_creation from dual;
exec dbms_lock.sleep (60);
select sysdate as slightly_before_dml from dual;

---- insert, update and delete on all base tables
delete from test_master where master_pk = 3;
commit;

-- gather stats on mv logs
exec dbms_stats.gather_table_stats (user, 'mlog$_test_master', cascade=>true, method_opt=>'for all columns size 1', force => true);

---- inspect mv logs
col M_ROW$$ form a25
col CHANGE_VECTOR$$ form a20
col dmltype$$ form a9
col old_new$$ form a9
select * from mlog$_test_master order by sequence$$;

--select m_row$$, snaptime$$, dmltype$$, old_new$$ from mlog$_test_master order by sequence$$;

-- wait to differentiate timestamps
select sysdate as slightly_after_dml from dual;
exec dbms_lock.sleep (60);
select sysdate as slightly_before_refresh from dual;

---- trace fast refresh
exec dbms_application_info.set_module(module_name => 'gby_sum_delo_mv_test_case',  action_name => 'gby_sum_delo_mv_test_case');

-- remove old files from directory user_dump_dest
host "rm /cygdrive/c/app/oracle/diag/rdbms/ora11ind/ora11ind/trace/*.trc"
host "rm /cygdrive/c/app/oracle/diag/rdbms/ora11ind/ora11ind/trace/*.trm"

show parameter user_dump_dest;
alter session set tracefile_identifier='gby_sum_delo_mv_test_case_&db_version.';
alter session set events '10046 trace name context forever, level 12';
 
exec dbms_mview.refresh ( list => 'test_mv', method => 'f', atomic_refresh => true); 

alter session set events '10046 trace name context off';

spool off

