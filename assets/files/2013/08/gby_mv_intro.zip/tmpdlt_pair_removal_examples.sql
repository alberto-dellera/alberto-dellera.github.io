-- Materialized View Fast Refresh Restrictions and ORA-12052 [ID 222843.1]
-- mv logs:
-- Contain all columns from the table referenced in the materialized view. 
-- Specify with ROWID and INCLUDING NEW VALUES.
-- Specify the SEQUENCE clause if the table is expected to have a mix of inserts/direct-loads, deletes, and updates.

-- http://docs.oracle.com/cd/E11882_01/server.112/e25554/basicmv.htm#g1014280 table 9-2

drop materialized view test_mv;
drop table test_master;

alter session set nls_date_format='dd/mm/yyyy hh24:mi:ss';

variable db_version varchar2(30)
declare
  l_dummy varchar2(100);
begin
  dbms_utility.db_version (:db_version, l_dummy);
end;
/

col db_version new_value db_version
select replace ( rtrim(:db_version,'.0'), '.', '_') as db_version from dual;

set echo on

spool tmpdlt_pair_removal_examples_&db_version..lst

-- base table test_master
create table test_master (whe int, gby int, dat int, not_referenced_in_mvlog int, master_pk int constraint test_master_pk primary key);
insert into test_master (whe, gby, dat, not_referenced_in_mvlog, master_pk) select 0, mod(rownum-1,2), 1, 1, rownum from dual connect by level < 1000;
create materialized view log on test_master with rowid(whe,gby,dat), sequence including new values;

-- create TMPDLT-similar view
drop view tmpdlt_test_master_view;

create or replace view tmpdlt_test_master_view
as
select /*+ result_cache(lifetime=session) */ 
			 rid$, gby, dat, whe,  
			 decode(old_new$$, 'N', 'I', 'D') dml$$,         
			 old_new$$,  snaptime$$, 
			 dmltype$$, 
			 sequence$$ -- added by AD  
 from (select log.*,   
							min( sequence$$ ) over (partition by rid$) min_sequence$$,   
							max( sequence$$ ) over (partition by rid$) max_sequence$$   
				 from (select chartorowid(m_row$$) rid$, gby, dat, whe, 
											dmltype$$, sequence$$, old_new$$, snaptime$$  
								 from mlog$_test_master     
							)   log 
			)  
where ( (old_new$$ in ('O', 'U') ) and (sequence$$ = min_sequence$$) ) 
	 or ( (old_new$$ = 'N'         ) and (sequence$$ = max_sequence$$) )
;

drop view inspector_view;
create or replace view  inspector_view
as
WITH TMPDLT$_TEST_MASTER AS ( 
  select * from tmpdlt_test_master_view
)                                                                                   
SELECT CASE WHEN ddt_1 ='D' AND ddt_2 ='I' THEN 'U' ELSE ddt_1 END DML$$,         
       MAX(SNAPTIME$$) as TIME$$  
  FROM (SELECT MIN(DML$$) OVER (PARTITION BY RID$, old_new) ddt_1, -- D,I,U               
               MAX(DML$$) OVER (PARTITION BY RID$, old_new) ddt_2, -- D,I,U
               SNAPTIME$$         
          FROM ( SELECT RID$, DML$$,                       
                        SNAPTIME$$,
                        CASE WHEN DMLTYPE$$ = 'U' AND OLD_NEW$$ = 'N'  THEN 'U' ELSE OLD_NEW$$ END old_new -- N,O,U
                   FROM TMPDLT$_TEST_MASTER DLT$ 
               ) V3 
       ) V4  
 GROUP BY CASE WHEN ddt_1 = 'D' AND ddt_2 = 'I' THEN 'U' ELSE ddt_1 END;

 
col M_ROW$$ form a25
col CHANGE_VECTOR$$ form a20
col dmltype$$ form a9
col old_new$$ form a9
col xid$$ form 99999999999999999999999999999

---- update chain
update test_master set dat=1000 where master_pk = 1;
update test_master set dat=2000 where master_pk = 1;
update test_master set dat=3000 where master_pk = 1;
-- read
select sequence$$, old_new$$, gby, dat, whe from mlog$_test_master order by sequence$$;
select sequence$$, old_new$$, gby, dat, whe from tmpdlt_test_master_view;
delete from  mlog$_test_master;
---- insert "reversed" by a delete
insert into test_master (whe, gby, dat, not_referenced_in_mvlog, master_pk) values (-1, -1, -1, -1, -1);
delete from test_master where master_pk = -1;
-- read
select sequence$$, old_new$$, gby, dat, whe from mlog$_test_master order by sequence$$;
select sequence$$, old_new$$, gby, dat, whe from tmpdlt_test_master_view;
delete from  mlog$_test_master;


/*
update test_master set not_referenced_in_mvlog=9999 where master_pk = 2;
insert into test_master (whe, gby, dat, not_referenced_in_mvlog, master_pk) values (-1, 3, 20, 20, -2);
delete from test_master where  master_pk = 99;
delete from test_master where master_pk in (1,2,-2); 

insert into test_master (whe, gby, dat, not_referenced_in_mvlog, master_pk) values (-1, 3, 20, 20, -1);
insert into test_master (whe, gby, dat, not_referenced_in_mvlog, master_pk) values (-1, 3, 20, 20, -2);
-- this delete just "reverses" an insert, and hence the MV refresh is insert-only
delete from test_master where master_pk = -2;
commit;
*/




spool off

