088 STATEMENT 88 xsqlid='DEL59j5885p1cgdr' xbstmt=85 xs[f=878 l=903] hv=1779842487 sqlid='59j5885p1cgdr'


/* MV_REFRESH (DEL) */ DELETE 
  FROM "DELLERA"."TEST_MV" "SNA$"
 WHERE ROWID IN ( SELECT RID 
                    FROM ( SELECT "SNA$".ROWID RID,  
                                   ROW_NUMBER() OVER (PARTITION BY "TEST_OUTER_ROWID" ORDER BY RID$ NULLS LAST) R,  
                                   COUNT(*)     OVER (PARTITION BY "TEST_OUTER_ROWID" ) T_CNT,  
                                   COUNT(RID$)  OVER (PARTITION BY "TEST_OUTER_ROWID" ) IN_MVLOG_CNT  
                             FROM "DELLERA"."TEST_MV" "SNA$", (SELECT DISTINCT RID$ 
                                                                 FROM (SELECT  CHARTOROWID("MAS$"."M_ROW$$") RID$     
                                                                         FROM "DELLERA"."MLOG$_TEST_INNER" "MAS$"   
                                                                        WHERE "MAS$".SNAPTIME$$ > :B_ST0 
                                                                       ) 
                                                               )  AS OF SNAPSHOT(:B_SCN) MAS$ 
                            WHERE "SNA$"."TEST_OUTER_ROWID" IN (SELECT "TEST_OUTER_ROWID" 
                                                                  FROM "DELLERA"."TEST_MV" "SNA$" 
                                                                 WHERE "TEST_INNER_ROWID" IN (SELECT * 
                                                                                                FROM (SELECT  CHARTOROWID("MAS$"."M_ROW$$") RID$     
                                                                                                        FROM "DELLERA"."MLOG$_TEST_INNER" "MAS$"   
                                                                                                       WHERE "MAS$".SNAPTIME$$ > :B_ST0 
                                                                                                     ) AS OF SNAPSHOT(:B_SCN) MAS$
                                                                                             )
                                                               ) 
                              AND "SNA$"."TEST_INNER_ROWID" = MAS$.RID$(+)                                       
                         ) "SNA2$" 
                   WHERE T_CNT > 1  
                     AND ( (IN_MVLOG_CNT = T_CNT AND R > 1) OR (IN_MVLOG_CNT < T_CNT AND R <= IN_MVLOG_CNT) ) 
                ) 
        

