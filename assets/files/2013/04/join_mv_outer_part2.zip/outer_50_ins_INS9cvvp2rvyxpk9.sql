093 STATEMENT 93 xsqlid='INS9cvvp2rvyxpk9' xbstmt=90 xs[f=962 l=974] hv=4159624777 sqlid='9cvvp2rvyxpk9'
    
/* MV_REFRESH (INS) */ INSERT INTO "DELLERA"."TEST_MV" 
SELECT /*+ NO_MERGE("JV$") */ "JV$"."JOUTER","JV$"."XOUTER","JV$"."PKOUTER","JV$"."RID$","MAS$0"."JINNER","MAS$0"."XINNER","MAS$0"."PKINNER","MAS$0".ROWID 
 FROM ( SELECT "MAS$"."ROWID" "RID$"  ,  
               "MAS$".*  
          FROM "DELLERA"."TEST_OUTER" "MAS$" 
         WHERE ROWID IN (SELECT CHARTOROWID("MAS$"."M_ROW$$") RID$     
                           FROM "DELLERA"."MLOG$_TEST_OUTER" "MAS$"   
                          WHERE "MAS$".SNAPTIME$$ > :B_ST1 
                         )
      )  AS OF SNAPSHOT(:B_SCN) "JV$", "TEST_INNER" AS OF SNAPSHOT(:B_SCN)  "MAS$0" 
WHERE "JV$"."JOUTER"="MAS$0"."JINNER"(+)
