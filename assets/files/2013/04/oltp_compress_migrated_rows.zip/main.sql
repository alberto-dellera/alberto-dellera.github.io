-- shows that migrated rows in a oltp-compressed table can be compressed
-- http://www.ixora.com.au/q+a/0107/27152941.htm for meaning of flags related to row migration

define test_tag=main

-- prepare spooling
alter session set nls_date_format='dd/mm/yyyy hh24:mi:ss';

variable db_version varchar2(30)
declare
  l_dummy varchar2(100);
begin
  dbms_utility.db_version (:db_version, l_dummy);
end;                                                        
/

col db_version new_value db_version
select replace ( rtrim(:db_version,'.0'), '.', '_') as db_version from dual;

set echo on
set serveroutput on
set trimspool on
spool &test_tag._&db_version..lst

-- remove old files from directory user_dump_dest
host "rm /cygdrive/c/app/oracle/diag/rdbms/ora11voda/ora11voda/trace/*.trc"
host "rm /cygdrive/c/app/oracle/diag/rdbms/ora11voda/ora11voda/trace/*.trm"

-- drop and recreate tablespace
alter session set events '10120 trace name context forever';
drop tablespace mssm including contents and datafiles;
create tablespace mssm datafile 'C:/APP/ORACLE/ORADATA/ORA11VODA/MSSM01.DBF' size 50M blocksize 4k extent management local uniform size 20M segment space management manual;

-- get db_block_size
col db_block_size  noprint new_value db_block_size
select value as db_block_size from v$parameter where name = 'db_block_size';

-- create table 
create table t (x varchar2(400 char))
tablespace mssm
pctfree 50
storage (freelists 1 initial 5000)
compress for oltp
;

-- populate table
insert /*+ append */ into t select rpad( 'A', 400, 'A') from dual connect by level <= 10000;
commit;

exec dbms_stats.gather_table_stats( user, 't', estimate_percent => 100);
select blocks from user_tables where table_name = 'T';

exec dump_blocks ('t', 'BLOCK#1', 'initial (after insert-append) - block#1');
                                                         
update t set x = lower(x);
commit;
       
-- alternate test: row-by-row update => nothing changes
-- begin
--   dbms_random.seed(0);
--   for r in (select rowid as row_id from t order by dbms_random.random)
--   loop
--     update t set x = lower(x) where rowid = r.row_id;
--     commit;
--   end loop;
-- end;
-- /   

-- check that a FTS does not follow the migrated row "forwarding addrees",
-- as single-row fetches must do
col tfcr_id  noprint new_value tfcr_id
select statistic# as tfcr_id from v$statname where name = 'table fetch continued row';

select value from v$mystat where statistic# = &tfcr_id.;
select /*+ full(t) */ count(*) from t;
select value from v$mystat where statistic# = &tfcr_id.;
declare
  l_dummy int;
begin
  for r in (select rowid as row_id from t order by dbms_random.random) 
  loop
    select count(*) into l_dummy from t where rowid = r.row_id;
  end loop;
end;
/
select value from v$mystat where statistic# = &tfcr_id.;

exec dump_blocks ('t', 'BLOCK#1', 'after update t set x = lower(x) - block#1');

-- exec dump_blocks ('t', 'BLOCK_RDBA#04000148', 'after update t set x = lower(x) - block containing migrated rows of block#1');

exec dump_blocks ('t', 'WITHOUT_ROWID', 'after update t set x = lower(x) - some of the blocks without external rowid', p_max_num_dumped => 10);

delete from t where dbms_rowid.rowid_row_number(rowid) not between 5 and 16;
commit;

exec dump_blocks ('t', 'BLOCK#1', 'after delete where rowid_block_number(rowid) not between 5 and 16 - block#1');

update t set x = upper(x);
commit;

exec dump_blocks ('t', 'BLOCK#1', 'after update t set x = upper(x) - block#1');

select value from v$parameter where name = 'user_dump_dest';                               

--exec dump_blocks ('t', 'WITH_ROWID');
--exec dump_blocks ('t', 'WITHOUT_ROWID');
--exec dump_blocks ('t', 'BLOCK#1');

spool off







