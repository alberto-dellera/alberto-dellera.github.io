--define mv_with=rowid
define mv_with="primary key"

define mv_with_under="**error**"
column mv_with_under new_value mv_with_under
select replace ('&mv_with.',' ','_') as mv_with_under from dual;

drop materialized view test_mv;
drop table test_t1;

alter session set nls_date_format='dd/mm/yyyy hh24:mi:ss';

variable db_version varchar2(30)
declare
  l_dummy varchar2(100);
begin
  dbms_utility.db_version (:db_version, l_dummy);
end;
/

col db_version new_value db_version
select replace ( rtrim(:db_version,'.0'), '.', '_') as db_version from dual;

set echo on

spool single_table_mv_&mv_with_under._&db_version..lst

---- create base table
-- jX_Y are the joined columns (X=table number, Y=name of the other table)
-- mv logs are set to "log everything loggable"

-- base table test_t1
create table test_t1 (x1 int, x2 int, pk1 int constraint test_t1_pk primary key);
insert into test_t1 (x1, x2, pk1) select rownum, rownum, rownum from dual connect by level < 100;
create index test_t1_x1_x2_idx on test_t1(x1, x2);
exec dbms_stats.gather_table_stats (user, 'test_t1', cascade=>true, method_opt=>'for all columns size 1');
create materialized view log on test_t1 with sequence, rowid, primary key (x1, x2) including new values;
--create materialized view log on test_t1 with primary key;
exec dbms_stats.gather_table_stats (user, 'mlog$_test_t1', cascade=>true, method_opt=>'for all columns size 1');

---- create single-table materialized view 
create materialized view test_mv
build immediate
refresh fast on demand
with &mv_with.
as
select test_t1.*, x1+x2 as x1x2
  from test_t1
 where x1 != 0.42
;

-- compute statistitcs on mv
exec dbms_stats.gather_table_stats (user, 'test_mv', cascade=>true, method_opt=>'for all columns size 1');

---- check mv is fast refreshable 
delete from mv_capabilities_table;

exec dbms_mview.explain_mview ( 'test_mv'); 

set lines 150
col capability_name form a30
col related_text form a10
col msgtxt form a100

select capability_name, possible, related_text, msgtxt from mv_capabilities_table
 where mvowner = user and mvname = 'TEST_MV'
   and capability_name like 'REFRESH%'
 order by capability_name;
 
-- wait to differentiate timestamps
select sysdate as slightly_after_creation from dual;
exec dbms_lock.sleep (60);
select sysdate as slightly_before_dml from dual;

---- insert, update and delete on base table
insert into test_t1 (x1, x2, pk1) values (1e9, 1e9, 1e9);
update test_t1 set pk1 = -pk1 where pk1 = 1;
update test_t1 set x1  = -x1  where pk1 = 2;
delete from test_t1           where pk1 = 3;
commit;

---- inspect mv logs
col M_ROW$$ form a25
col CHANGE_VECTOR$$ form a20
col dmltype$$ form a9
col old_new$$ form a9
select * from mlog$_test_t1 order by sequence$$;

--select m_row$$, snaptime$$, dmltype$$, old_new$$ from mlog$_test_t1 order by sequence$$;

-- wait to differentiate timestamps
select sysdate as slightly_after_dml from dual;
exec dbms_lock.sleep (60);
select sysdate as slightly_before_refresh from dual;

---- trace fast refresh
exec dbms_application_info.set_module(module_name => 'single_table_mv',  action_name => 'single_table_mv');

show parameter user_dump_dest;
alter session set tracefile_identifier='single_table_mv_&mv_with_under._&db_version.';
alter session set events '10046 trace name context forever, level 12';
 
exec dbms_mview.refresh ( list => 'test_mv', method => 'f', atomic_refresh => true); 

alter session set events '10046 trace name context off';

spool off

