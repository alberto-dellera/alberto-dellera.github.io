6519   EXEC : xbsqlid=:upd2AYS5ZIIDI1U2/UPD8gh5rzz78y32j dep=1

/* MV_REFRESH (UPD) */ 
UPDATE /*+ BYPASS_UJVC */ 
(SELECT /*+ NO_MERGE ("JV$") */ "SNA$"."JINNER" "C0_0", "JV$"."JINNER" "C1_0", "SNA$"."XINNER" "C0_1", "JV$"."XINNER" "C1_1", 
                                "SNA$"."PKINNER" "C0_2", "JV$"."PKINNER" "C1_2", "SNA$"."TEST_INNER_ROWID" "C0_3", "JV$"."RID$" "C1_3" 
  FROM ( SELECT "MAS$"."ROWID" "RID$"  ,  "MAS$".*  
           FROM "DELLERA"."TEST_INNER" "MAS$" 
         WHERE ROWID IN (SELECT  CHARTOROWID("MAS$"."M_ROW$$") RID$    
                           FROM "DELLERA"."MLOG$_TEST_INNER" "MAS$"   
                          WHERE "MAS$".SNAPTIME$$ > :B_ST0 
                        )
       )  AS OF SNAPSHOT(:B_SCN) "JV$",
       "TEST_OUTER" AS OF SNAPSHOT(:B_SCN)  "MAS$1", 
       "DELLERA"."TEST_MV" "SNA$" 
 WHERE "MAS$1"."JOUTER"="JV$"."JINNER" 
   AND "SNA$"."TEST_OUTER_ROWID" = "MAS$1".ROWID  
) UV$ 
SET "C0_0"="C1_0", "C0_1"="C1_1", "C0_2"="C1_2", "C0_3"="C1_3"
