090 STATEMENT 90 xsqlid='INSg805du9uaswu8' xbstmt=87 xs[f=914 l=927] hv=1957458760 sqlid='g805du9uaswu8'

/* MV_REFRESH (INS) */ INSERT INTO "DELLERA"."TEST_MV" 
SELECT /*+ NO_MERGE("JV$") */ 
       "MAS$1"."JOUTER",
       "MAS$1"."XOUTER",
       "MAS$1"."PKOUTER",
       "MAS$1".ROWID,
       "JV$"."JINNER",
       "JV$"."XINNER",
       "JV$"."PKINNER",
       "JV$"."RID$" 
  FROM ( SELECT "MAS$"."ROWID" "RID$"  ,  
                "MAS$".*  
           FROM "DELLERA"."TEST_INNER" "MAS$" 
          WHERE ROWID IN (SELECT  CHARTOROWID("MAS$"."M_ROW$$") RID$     
                            FROM "DELLERA"."MLOG$_TEST_INNER" "MAS$"   
                           WHERE "MAS$".SNAPTIME$$ > :B_ST0 
                         )
       )  AS OF SNAPSHOT(:B_SCN) "JV$", "TEST_OUTER" AS OF SNAPSHOT(:B_SCN)  "MAS$1" 
 WHERE "MAS$1"."JOUTER"="JV$"."JINNER"
