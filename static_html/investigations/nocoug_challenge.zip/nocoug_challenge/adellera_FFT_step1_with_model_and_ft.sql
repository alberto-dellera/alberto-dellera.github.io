

-- F( p(i) ) (f) = sum [ i=0..num_frequencies-1, p(i) * exp (2 * PI * IMAG_UNIT * i * f / num_frequencies) ]

with constants as (
  select (select max (face_value) from die where probability != 0)          as max_s_1,
         (select max (face_value) from die where probability != 0) * :N     as max_s_N,
         (select max (face_value) from die where probability != 0) * :N + 1 as num_frequencies,
         3.14159265358979323846264338327950288419716939937510 as PI
    from dual
), i_sequence as (
  select rownum-1 as i from dual connect by level <= (select num_frequencies from constants)
), base_frequencies as (
  select i, 
         - 2 * (select PI from constants ) * i / (select num_frequencies from constants) as base_frequency
    from i_sequence
), p_s_1 as (
  select i as s, nvl (die.probability, 0) as probability
    from i_sequence, die
   where i_sequence.i = die.face_value(+)
     and die.probability(+) != 0
), dft_p_s_1 as (
   select f, real, imag
     from (select i as f from i_sequence) 
   model         
     reference co on (select 0 dummy, c.* from constants c)
       dimension by (dummy)
       measures ( num_frequencies)
     reference bf on (select * from base_frequencies)
       dimension by (i)
       measures ( base_frequency )  
     reference p_s_1 on (select * from p_s_1)
       dimension by (s)
       measures (probability)
     main m
     dimension by (f)
     measures (0 real, 0 imag, 0 counter)
     rules iterate(999999) until (iteration_number + 1 = co.num_frequencies[0]) 
     (
       real[any] = real[cv(f)] + p_s_1.probability[iteration_number] * cos ( bf.base_frequency[iteration_number] * cv(f) ),
       imag[any] = imag[cv(f)] + p_s_1.probability[iteration_number] * sin ( bf.base_frequency[iteration_number] * cv(f) )
     )
  --select base_frequencies.i as f,
  --       sum ( p_s_1.probability * cos ( base_frequencies.base_frequency * p_s_1.s  ) ) as real,
  --       sum ( p_s_1.probability * sin ( base_frequencies.base_frequency * p_s_1.s  ) ) as imag
  --  from p_s_1, base_frequencies
  -- group by base_frequencies.i
), dft_p_s_1_polar as (
  select f, 
         sqrt ( real * real + imag * imag ) as modulus,
         atan2 ( imag , real ) as phase
    from dft_p_s_1
), dft_p_s_N_polar as (
  select f,
         power (modulus , :N) as modulus,
         phase * :N as phase
    from dft_p_s_1_polar
), dft_p_s_N as ( 
  select f, 
         modulus * cos (phase) as real,
         modulus * sin (phase) as imag
    from dft_p_s_N_polar
), p_s_N as (
  select base_frequencies.i as s,
         sum ( dft_p_s_N.real * cos ( - base_frequencies.base_frequency * dft_p_s_N.f  ) 
             - dft_p_s_N.imag * sin ( - base_frequencies.base_frequency * dft_p_s_N.f  ) 
             ) / (select num_frequencies from constants) as probability
    from dft_p_s_N, base_frequencies
   group by base_frequencies.i
) 
select * from p_s_N order by s;
*/

