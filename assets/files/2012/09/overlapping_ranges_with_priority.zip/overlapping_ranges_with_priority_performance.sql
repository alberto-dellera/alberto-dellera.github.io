define test_tag=overlapping_ranges_with_priority_performance

alter session set nls_date_format='dd/mm/yyyy hh24:mi:ss';

variable db_version varchar2(30)
declare
  l_dummy varchar2(100);
begin
  dbms_utility.db_version (:db_version, l_dummy);
end;
/

col db_version new_value db_version
select replace ( rtrim(:db_version,'.0'), '.', '_') as db_version from dual;

set echo on

spool &test_tag._&db_version..lst

@original_with_view.sql

col sku form a4
col a form a2
col b form a2
col sa form a2
col sb form a2
col prio form 9999
col price form 9999
col range_coded form a24

truncate table ranges;

insert /*+ append */ into ranges(sku, a, b, prio, price)
select sku.sku, pp.a, pp.b, pp.prio, pp.price 
  from (select 'k'||rownum as sku from dual connect by level <= 100000) sku,
       (select 100 as a, 200 as b, 100 as prio, 100 as price from dual
        union all
        select 150 as a, 250 as b, 150 as prio, 150 as price from dual) pp
;
commit;

exec dbms_stats.gather_table_stats (user, 'ranges', cascade=>true, method_opt=>'for all columns size 1', estimate_percent => null);

alter session set statistics_level=all;

---- equality predicate on sku applied on view can be pushed down to table
explain plan for
select * from ranges_output_view where sku = 'k100';

select * from table (dbms_xplan.display);

-- parallel can be applied to view 
alter session force parallel query parallel 4;

explain plan for
select * from ranges_output_view;

select * from table (dbms_xplan.display);

alter session disable parallel query;

spool off

