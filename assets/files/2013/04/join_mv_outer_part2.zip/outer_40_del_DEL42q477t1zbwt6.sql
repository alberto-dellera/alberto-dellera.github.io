092 STATEMENT 92 xsqlid='DEL42q477t1zbwt6' xbstmt=89 xs[f=952 l=960] hv=1140192038 sqlid='42q477t1zbwt6'
    
/* MV_REFRESH (DEL) */ 
DELETE FROM "DELLERA"."TEST_MV" SNA$ 
 WHERE "TEST_OUTER_ROWID" IN (SELECT /*+ NO_MERGE  */ * 
                                FROM (SELECT  CHARTOROWID("MAS$"."M_ROW$$") RID$     
                                        FROM "DELLERA"."MLOG$_TEST_OUTER" "MAS$"   
                                       WHERE "MAS$".SNAPTIME$$ > :B_ST1 
                                     ) AS OF SNAPSHOT(:B_SCN) MAS$
                              ); 
