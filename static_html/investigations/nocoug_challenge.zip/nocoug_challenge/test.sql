
col probability form 999.999999999

variable N number

exec :N := 1;

set timing on
set echo on

alter session set workarea_size_policy=manual;
alter session set sort_area_size=100000000;
alter session set hash_area_size=100000000;

-- @laurent.sql

-- @model.sql

--@adellera_ft.sql

@adellera_fft.sql