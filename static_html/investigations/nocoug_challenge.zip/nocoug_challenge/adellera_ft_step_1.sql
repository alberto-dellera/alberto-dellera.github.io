

-- F( p(i) ) (f) = sum [ i=0..num_frequencies-1, p(i) * exp (2 * PI * IMAG_UNIT * i * f / num_frequencies) ]

with constants as (
  select (select max (face_value) from die where probability != 0)          as max_s_1,
         (select max (face_value) from die where probability != 0) * :N     as max_s_N,
         (select max (face_value) from die where probability != 0) * :N + 1 as num_frequencies,
         3.14159265358979323846264338327950288419716939937510 as PI
    from dual
), i_sequence as (
  select rownum-1 as i from dual connect by level <= (select num_frequencies from constants)
), base_frequencies as (
  select i, 
         - 2 * (select PI from constants ) * i / (select num_frequencies from constants) as base_frequency
    from i_sequence
), p_s_1 as (
  select i as s, nvl (die.probability, 0) as probability
    from i_sequence, die
   where i_sequence.i = die.face_value(+)
     and die.probability(+) != 0
), dft_p_s_1 as (
  select base_frequencies.i as f,
         sum ( p_s_1.probability * cos ( base_frequencies.base_frequency * p_s_1.s  ) ) as real,
         sum ( p_s_1.probability * sin ( base_frequencies.base_frequency * p_s_1.s  ) ) as imag
    from p_s_1, base_frequencies
   group by base_frequencies.i
), inv_dft_p_s_1 as (
  select base_frequencies.i as s,
         sum ( dft_p_s_1.real * cos ( - base_frequencies.base_frequency * dft_p_s_1.f  ) 
         - dft_p_s_1.imag * sin ( - base_frequencies.base_frequency * dft_p_s_1.f  ) 
             ) / (select num_frequencies from constants) as probability
    from dft_p_s_1, base_frequencies
   group by base_frequencies.i
) 
select * from inv_dft_p_s_1 order by s;


