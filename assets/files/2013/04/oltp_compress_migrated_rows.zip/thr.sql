-- tosp=0x7fe -> 2046
-- row 122 triggers
-- out from freelist at tosp=0x7d8 -> 2008 

define test_tag=thr

-- prepare spooling
alter session set nls_date_format='dd/mm/yyyy hh24:mi:ss';

variable db_version varchar2(30)
declare
  l_dummy varchar2(100);
begin
  dbms_utility.db_version (:db_version, l_dummy);
end;                                                        
/

col db_version new_value db_version
select replace ( rtrim(:db_version,'.0'), '.', '_') as db_version from dual;

set echo on
set serveroutput on
set trimspool on
spool &test_tag._&db_version..lst

-- remove old files from directory user_dump_dest
host "rm /cygdrive/c/app/oracle/diag/rdbms/ora11voda/ora11voda/trace/*.trc"
host "rm /cygdrive/c/app/oracle/diag/rdbms/ora11voda/ora11voda/trace/*.trm"

-- drop and recreate tablespace
alter session set events '10120 trace name context forever';
drop tablespace mssm including contents and datafiles;
create tablespace mssm datafile 'C:/APP/ORACLE/ORADATA/ORA11VODA/MSSM01.DBF' size 50M blocksize 4k extent management local uniform size 20M segment space management manual;

-- get db_block_size
col db_block_size  noprint new_value db_block_size
select value as db_block_size from v$parameter where name = 'db_block_size';

-- create table 
create table t (x varchar2(400 char))
tablespace mssm
pctfree 50
storage (freelists 1 initial 5000)
compress for oltp
;

declare
  l_rowid rowid;
begin
  for i in 1..200 loop
    insert into t(x) values( rpad( 'A', 10, 'A') ) returning rowid into l_rowid;
    commit;
    dbms_output.put_line('row #'||i||' '||dbms_rowid.rowid_block_number(l_rowid));
    --dump_blocks ('t', 'BLOCK#1', 'after insert#'||i);
  end loop;
end;
/

select value from v$parameter where name = 'user_dump_dest';                               

exec dump_blocks ('t', 'BLOCK#1');

spool off







