-- 578720.1
-- 875532.1

define underscore_value=not_set
--define underscore_value=true
define test_tag=locked_stats 

drop materialized view test_mv;
drop table test_t1;
drop table test_t2;

alter session set nls_date_format='dd/mm/yyyy hh24:mi:ss';

variable db_version varchar2(30)
declare
  l_dummy varchar2(100);
begin
  dbms_utility.db_version (:db_version, l_dummy);
end;
/

col db_version new_value db_version
select replace ( rtrim(:db_version,'.0'), '.', '_') as db_version from dual;

set echo on

spool join_mv_&test_tag._&db_version..lst

---- create base tables
-- jX_Y are the joined columns (X=table number, Y=name of the other table)                                     
-- mv logs are set to "log everything loggable"

-- base table test_t1
create table test_t1 (j1_2 int, x1 int, pk1 int constraint test_t1_pk primary key);
insert into test_t1 (j1_2, x1, pk1) select rownum, 100000 + rownum, rownum from dual connect by level <= 100000;
create index test_t1_j1_2_idx on test_t1(j1_2);
exec dbms_stats.gather_table_stats (user, 'test_t1', cascade=>true, method_opt=>'for all columns size 1');
create materialized view log on test_t1 with sequence, rowid, primary key (j1_2, x1) including new values;
exec dbms_stats.gather_table_stats (user, 'mlog$_test_t1', cascade=>true, method_opt=>'for all columns size 1');
exec dbms_stats.lock_table_stats(user, 'mlog$_test_t1');  

-- create index mlog_test_t1_idx on mlog$_test_t1 (snaptime$$, old_new$$, dmltype$$, m_row$$) compress 3;

-- base table test_t2
create table test_t2 (j2_1 int, x2 int, pk2 int constraint test_t2_pk primary key);
insert into test_t2 (j2_1, x2, pk2) select rownum, 100000 + rownum, rownum from dual connect by level <= 100000;
create index test_t2_j2_1_idx on test_t2(j2_1);
exec dbms_stats.gather_table_stats (user, 'test_t2', cascade=>true, method_opt=>'for all columns size 1');
create materialized view log on test_t2 with sequence, rowid, primary key (j2_1, x2) including new values;
exec dbms_stats.gather_table_stats (user, 'mlog$_test_t2', cascade=>true, method_opt=>'for all columns size 1');
exec dbms_stats.lock_table_stats(user, 'mlog$_test_t2'); 

-- create index mlog_test_t2_idx on mlog$_test_t2 (snaptime$$, old_new$$, dmltype$$, m_row$$) compress 3;

---- create join-only materialized view 
create materialized view test_mv
build immediate
refresh fast on demand
as
select test_t1.*, test_t1.rowid as test_t1_rowid,
       test_t2.*, test_t2.rowid as test_t2_rowid
  from test_t1, test_t2
 where test_t1.j1_2 = test_t2.j2_1
;                                                                                                     
                                                                                               
-- create indexes on columns tracking the rowid of base tables
create index test_mv_test_t1_rowid on test_mv (test_t1_rowid);
create index test_mv_test_t2_rowid on test_mv (test_t2_rowid);
exec dbms_stats.gather_table_stats (user, 'test_mv', cascade=>true, method_opt=>'for all columns size 1');

---- check mv is fast refreshable 
delete from mv_capabilities_table;

exec dbms_mview.explain_mview ( 'test_mv' ); 

set lines 150
col capability_name form a30
col related_text form a10
col msgtxt form a100

select capability_name, possible, related_text, msgtxt from mv_capabilities_table
 where mvowner = user and mvname = 'TEST_MV'
   and capability_name like 'REFRESH%'
 order by capability_name;
 
-- wait to differentiate timestamps
--select sysdate as slightly_after_creation from dual;
--exec dbms_lock.sleep (60);
--select sysdate as slightly_before_dml from dual;

---- insert, update and delete on all base tables
insert into test_t1 (j1_2, x1, pk1) values (1e9, 1e9, 1e9);
insert into test_t2 (j2_1, x2, pk2) values (1e9, 1e9, 1e9);
update test_t1 set j1_2 = 1e9+99 where pk1 = 1;
update test_t2 set j2_1 = 1e9+99 where pk2 = 1;
update test_t1 set x1 = -x1 where pk1 = 2;
update test_t2 set x2 = -x2 where pk2 = 2;
delete from test_t1 where pk1 = 3;
delete from test_t2 where pk2 = 3;
commit;

--exec dbms_stats.gather_table_stats (user, 'mlog$_test_t1', cascade=>true, method_opt=>'for all columns size 1');
--exec dbms_stats.gather_table_stats (user, 'mlog$_test_t2', cascade=>true, method_opt=>'for all columns size 1');

---- inspect mv logs
col M_ROW$$ form a25
col CHANGE_VECTOR$$ form a20
col dmltype$$ form a9
col old_new$$ form a9
select * from mlog$_test_t1 order by sequence$$;
select * from mlog$_test_t2 order by sequence$$;

---- trace fast refresh
exec dbms_application_info.set_module(module_name => 'join_mv_&test_tag.',  action_name => 'join_mv_&test_tag.');

begin
  if '&underscore_value.' in ('true','false') then
    execute immediate 'alter session set "_mv_refresh_use_stats"=true';
  end if;
end;
/
--alter session set "_optimizer_ignore_hints"=true; 
alter system flush shared_pool;
 
exec dbms_mview.refresh ( list => 'test_mv', method => 'f', atomic_refresh => true); 

@xplan "%mv_refresh%mlog$_test_t1%" "module=join_mv_&test_tag.,tabinfos=n,objinfos=n,spool_name=join_mv_&test_tag._&db_version._plans.lst"

spool off

exit


