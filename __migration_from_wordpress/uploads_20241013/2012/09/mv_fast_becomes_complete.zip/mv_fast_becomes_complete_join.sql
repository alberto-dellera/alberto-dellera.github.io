define test_tag=mv_fast_becomes_complete_join

alter session set nls_date_format='dd/mm/yyyy hh24:mi:ss';

variable db_version varchar2(30)
declare
  l_dummy varchar2(100);
begin
  dbms_utility.db_version (:db_version, l_dummy);
end;
/

col db_version new_value db_version
select replace ( rtrim(:db_version,'.0'), '.', '_') as db_version from dual;

set echo on

spool &test_tag._&db_version..lst

drop materialized view dellera_mv3;
drop materialized view dellera_mv2;
drop materialized view dellera_mv1;
drop table dellera_t;

drop materialized view join_dellera_mv3;
drop materialized view join_dellera_mv2;
drop materialized view join_dellera_mv1;
drop table join_dellera_t;

col mview_name form a20

whenever sqlerror exit

set echo on
set serveroutput on

---- create master table and nested MVs

create table dellera_t as select rownum as x, rownum as y from dual connect by level <= 3;

create materialized view log on dellera_t with rowid;

create table join_dellera_t as select rownum as x, rownum as y from dual connect by level <= 3;

create materialized view log on join_dellera_t with rowid;

create materialized view dellera_mv1
build immediate
refresh fast on demand
with rowid
as
select d.x, d.y, d.rowid as rid#d,
       j.x as d_x, j.y as j_y, j.rowid as rid#j
  from dellera_t d, join_dellera_t j
 where d.x = j.x;

create materialized view log on dellera_mv1 with rowid;

create materialized view join_dellera_mv1
build immediate
refresh fast on demand
with rowid
as
select x, y, rowid as rid# from join_dellera_t;

create materialized view log on join_dellera_mv1 with rowid;

create materialized view dellera_mv2
build immediate
refresh fast on demand
with rowid
as
select d.x, d.y, d.rowid as rid#d,
       j.x as d_x, j.y as j_y, j.rowid as rid#j
  from dellera_mv1 d, join_dellera_mv1 j
 where d.x = j.x;
  
create materialized view log on dellera_mv2 with rowid; 

create materialized view join_dellera_mv2
build immediate
refresh fast on demand
with rowid
as
select x, y, rowid as rid#   
  from join_dellera_mv1;
  
create materialized view log on join_dellera_mv2 with rowid; 

create materialized view dellera_mv3
build immediate
refresh fast on demand
with rowid
as
select d.x, d.y, d.rowid as rid#d,
       j.x as d_x, j.y as j_y, j.rowid as rid#j 
  from dellera_mv2 d, join_dellera_mv2 j
 where d.x = j.x; 
  
create materialized view join_dellera_mv3
build immediate
refresh fast on demand
with rowid
as
select x, y, rowid as rid#   
  from join_dellera_mv2;  
  
-- populate mvlog of master table

update dellera_t set y = y +1;
commit;

-- refresh complete MV1

exec dbms_mview.refresh('dellera_mv1', method=>'c', atomic_refresh => true);

-- verify that NO row exists in MV1 mvlog

select count(*) from mlog$_dellera_mv1;

-- refresh fast MV2 (silently becomes complete)

exec dbms_mview.refresh('dellera_mv2', method=>'f', atomic_refresh => true);

-- verify that NO row exists in MV2 mvlog

select count(*) from mlog$_dellera_mv2;

alter session set events '10046 trace name context off';

-- refresh fast MV3 (silently becomes complete)

exec dbms_mview.refresh('dellera_mv3', method=>'f', atomic_refresh => true);

-- check that all refreshes were indeed complete

select mview_name, last_refresh_type from user_mviews where mview_name like 'DELLERA%' order by mview_name;

spool off

