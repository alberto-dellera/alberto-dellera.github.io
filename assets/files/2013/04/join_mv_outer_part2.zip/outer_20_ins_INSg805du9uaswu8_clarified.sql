/* MV_REFRESH (INS) */ 
insert into test_mv 
select  o.jouter,  o.xouter,  o.pkouter, o.rowid,
       jv.jinner, jv.xinner, jv.pkinner, jv.rid 
  from ( select test_inner.rowid rid,  
                test_inner.*  
           from test_inner 
          where rowid in (select rid$ from mlog_test_inner)
       ) jv, test_outer o 
 where jv.jinner = o.jouter 
