/* MV_REFRESH (UPD) */ 
update /*+ bypass_ujvc */ (
select test_mv.jinner           target_0, jv.jinner  source_0, 
       test_mv.xinner           target_1, jv.xinner  source_1, 
       test_mv.pkinner          target_2, jv.pkinner source_2, 
       test_mv.test_inner_rowid target_3, jv.rid$    source_3 
 from ( select test_inner.rowid rid$, test_inner.*  
          from test_inner
         where rowid in (select rid$ from mlog$_test_inner)
      ) jv,
      test_outer, 
      test_mv                 
where test_outer.jouter = jv.jinner 
  and test_mv.test_outer_rowid = test_outer.rowid  
) 
set target_0 = source_0, 
    target_1 = source_1, 
    target_2 = source_2, 
    target_3 = source_3       
