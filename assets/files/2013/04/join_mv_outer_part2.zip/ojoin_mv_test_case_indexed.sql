drop materialized view test_mv;
drop table test_outer;
drop table test_inner;

alter session set nls_date_format='dd/mm/yyyy hh24:mi:ss';

variable db_version varchar2(30)
declare
  l_dummy varchar2(100);
begin
  dbms_utility.db_version (:db_version, l_dummy);
end;
/

col db_version new_value db_version
select replace ( rtrim(:db_version,'.0'), '.', '_') as db_version from dual;

set echo on

spool ojoin_mv_test_case_indexed_&db_version..lst

---- create base tables
-- jX_Y are the joined columns (X=table number, Y=name of the other table)
-- mv logs are set to "log everything loggable"

-- base table test_outer
create table test_outer (jouter int, xouter int, pkouter int constraint test_outer_pk primary key);
insert into test_outer (jouter, xouter, pkouter) select rownum, 100000 + rownum, rownum from dual connect by level < 100;
create index test_outer_jouter_idx on test_outer(jouter);
exec dbms_stats.gather_table_stats (user, 'test_outer', cascade=>true, method_opt=>'for all columns size 1');
create materialized view log on test_outer with sequence, rowid, primary key (jouter, xouter) including new values;
-- create index mlog_test_outer_idx on mlog$_test_outer (snaptime$$, old_new$$, dmltype$$, m_row$$) compress 3;
exec dbms_stats.gather_table_stats (user, 'mlog$_test_outer', cascade=>true, method_opt=>'for all columns size 1');
exec dbms_stats.lock_table_stats(user, 'mlog$_test_outer');

-- base table test_inner
create table test_inner (jinner int, xinner int, pkinner int constraint test_inner_pk primary key);
insert into test_inner (jinner, xinner, pkinner) select rownum, 100000 + rownum, rownum from dual connect by level <= 100;
create index test_inner_jinner_idx on test_inner(jinner);
exec dbms_stats.gather_table_stats (user, 'test_inner', cascade=>true, method_opt=>'for all columns size 1');
create materialized view log on test_inner with sequence, rowid, primary key (jinner, xinner) including new values;
-- create index mlog_test_inner_idx on mlog$_test_inner (snaptime$$, old_new$$, dmltype$$, m_row$$) compress 3;
exec dbms_stats.gather_table_stats (user, 'mlog$_test_inner', cascade=>true, method_opt=>'for all columns size 1');
exec dbms_stats.lock_table_stats(user, 'mlog$_test_inner');

---- create join-only materialized view 
create materialized view test_mv
build immediate
refresh fast on demand
as
select test_outer.*, test_outer.rowid as test_outer_rowid,
       test_inner.*, test_inner.rowid as test_inner_rowid
  from test_outer, test_inner
 where test_outer.jouter = test_inner.jinner(+)
;

-- create indexes on columns tracking the rowid of base tables
create index test_mv_test_outer_rowid on test_mv (test_outer_rowid, test_inner_rowid);
create index test_mv_test_inner_rowid on test_mv (test_inner_rowid, test_outer_rowid);
exec dbms_stats.gather_table_stats (user, 'test_mv', cascade=>true, method_opt=>'for all columns size 1');

---- check mv is fast refreshable 
delete from mv_capabilities_table;

exec dbms_mview.explain_mview ( 'test_mv' ); 

set lines 150
col capability_name form a30
col related_text form a10
col msgtxt form a100

select capability_name, possible, related_text, msgtxt from mv_capabilities_table
 where mvowner = user and mvname = 'TEST_MV'
   and capability_name like 'REFRESH%'
 order by capability_name;
 
-- wait to differentiate timestamps
select sysdate as slightly_after_creation from dual;
exec dbms_lock.sleep (60);
select sysdate as slightly_before_dml from dual;

---- insert, update and delete on all base tables
insert into test_outer (jouter, xouter, pkouter) values (1e9, 1e9, 1e9);
insert into test_inner (jinner, xinner, pkinner) values (1e9, 1e9, 1e9);
update test_outer set jouter = 1e9+99 where pkouter = 1;
update test_inner set jinner = 1e9+99 where pkinner = 1;
update test_outer set xouter = -xouter where pkouter = 2;
update test_inner set xinner = -xinner where pkinner = 2;
delete from test_outer where pkouter = 3;
delete from test_inner where pkinner = 3;
commit;

--exec dbms_stats.gather_table_stats (user, 'mlog$_test_outer', cascade=>true, method_opt=>'for all columns size 1');
--exec dbms_stats.gather_table_stats (user, 'mlog$_test_inner', cascade=>true, method_opt=>'for all columns size 1');

---- inspect mv logs
col M_ROW$$ form a25
col CHANGE_VECTOR$$ form a20
col dmltype$$ form a9
col old_new$$ form a9
select * from mlog$_test_outer order by sequence$$;
select * from mlog$_test_inner order by sequence$$;

--select m_row$$, snaptime$$, dmltype$$, old_new$$ from mlog$_test_outer order by sequence$$;

-- wait to differentiate timestamps
select sysdate as slightly_after_dml from dual;
exec dbms_lock.sleep (60);
select sysdate as slightly_before_refresh from dual;

alter system flush shared_pool;

---- trace fast refresh
exec dbms_application_info.set_module(module_name => 'ojoin_mv_test_case',  action_name => 'ojoin_mv_test_case');

--show parameter user_dump_dest;
--alter session set tracefile_identifier='ojoin_mv_test_case_indexed_&db_version.';
--alter session set events '10046 trace name context forever, level 12';
 
exec dbms_mview.refresh ( list => 'test_mv', method => 'f', atomic_refresh => true); 

--alter session set events '10046 trace name context off';

@xplan "%mv_refresh%" "ti=n,oi=n"

spool off

