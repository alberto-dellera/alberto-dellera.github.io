/* MV_REFRESH (DEL) */ 
delete from test_mv sna$ where rowid in (
select rid 
 from ( 
select test_mv.rowid rid,
       row_number()            over ( partition by test_outer_rowid order by test_inner_rowid nulls first) r,  
       count(*)                over ( partition by test_outer_rowid ) t_cnt,  
       count(test_inner_rowid) over ( partition by test_outer_rowid ) nonnull_cnt  
  from test_mv 
 where /* read touched outer slices start */
       test_mv.test_outer_rowid in 
          (
          select o.rowid  
            from ( select test_inner.rowid rid$,  
                          test_inner.*  
                     from test_inner
                    where rowid in (select rid$ from mlog$_test_inner)
                 ) jv, test_outer o 
           where jv.jinner = o.jouter 
          ) 
      /* read touched outer slices end */    
      )  
 /* victim selection start */     
 where t_cnt > 1  
   and ( (nonnull_cnt = 0 and r > 1) 
          or 
         (nonnull_cnt > 0 and r <= t_cnt - nonnull_cnt) 
       ) 
 /* victim selection end */
) 
