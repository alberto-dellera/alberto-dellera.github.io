set echo on

drop table dump_blocks_gtt;

create table dump_blocks_gtt as select file_id, block_id from dba_extents where 1=0;

create or replace procedure dump_blocks ( 
  p_table_name     varchar2, 
  p_dump_type      varchar2 default 'ALL', 
  p_message        varchar2 default null, 
  p_max_num_dumped int default null
)
is  
  l_total_blocks              number;
  l_total_bytes               number;
  l_unused_blocks             number;
  l_unused_bytes              number;
  l_last_used_extent_file_id  number;
  l_last_used_extent_block_id number;
  l_last_used_block           number;
  l_num int;
  l_stmt long;
  l_block_num int;
  l_dba_file_id_relative number;
  l_dba_file_id       number;
  l_dba_file_block_id number;
  l_dba_string varchar2(40 char);
  
  procedure exec (p_stmt varchar2)
  is
  begin
    dbms_output.put_line(p_stmt);
    execute immediate p_stmt;
  end exec;
begin
  if p_dump_type like 'BLOCK\_RDBA#%' escape '\' then
    l_dba_string := substr( upper(p_dump_type), instr ( upper(p_dump_type), '0X') + 2 ); 
    -- for DBA to file_id/block_id:  http://jonathanlewis.wordpress.com/oracle-core/oc-2-undo-and-redo/
    l_dba_file_id_relative := dbms_utility.data_block_address_file (to_number(l_dba_string,'XXXXXXXX')) ;
    l_dba_file_block_id    := dbms_utility.data_block_address_block(to_number(l_dba_string,'XXXXXXXX')) ;
    
    select file_id into l_dba_file_id 
      from dba_data_files 
     where tablespace_name = (select tablespace_name from user_tables where table_name = upper(p_table_name));
     
    sys.dbms_system.ksdwrt(1, '---------------------------------------------------------------------------------------------------------------------------------------------------------------');
    sys.dbms_system.ksdwrt(1, 'dumping block with RELATIVE DBA rdba=0x'||l_dba_string);
    
    sys.dbms_system.ksdwrt(1, '---------------------------------------------------------------------------------------------------------------------------------------------------------------');
    execute immediate 'alter system dump datafile '||l_dba_file_id||' block min '||l_dba_file_block_id||' block max '||l_dba_file_block_id;
    return;
  end if;
  
  -- get HWM block
  dbms_space.unused_space (segment_owner              => user, 
                           segment_name               => upper(p_table_name),
                           segment_type               => 'table',
                           total_blocks               => l_total_blocks,
                           total_bytes                => l_total_bytes,
                           unused_blocks              => l_unused_blocks,
                           unused_bytes               => l_unused_bytes,
                           last_used_extent_file_id   => l_last_used_extent_file_id,
                           last_used_extent_block_id  => l_last_used_extent_block_id,
                           last_used_block            => l_last_used_block);


  --dbms_output.put_line('l_total_blocks              :' || l_total_blocks);
  --dbms_output.put_line('l_total_bytes               :' || l_total_bytes);
  --dbms_output.put_line('l_unused_blocks             :' || l_unused_blocks);
  --dbms_output.put_line('l_unused_bytes              :' || l_unused_bytes);
  dbms_output.put_line('l_last_used_extent_file_id  :' || l_last_used_extent_file_id);
  dbms_output.put_line('l_last_used_extent_block_id :' || l_last_used_extent_block_id);
  dbms_output.put_line('l_last_used_block           :' || l_last_used_block);
  
  -- dump blocks
  delete from dump_blocks_gtt;
  
  l_num := 0;
  for e in (select file_id, block_id, blocks from dba_extents where owner = user and segment_name=upper(p_table_name))
  loop
    insert into dump_blocks_gtt (file_id, block_id)
    select e.file_id, e.block_id + (rownum-1) from dual connect by level <= e.blocks;
    -- check there is only one extent
    l_num := l_num + 1;
    if l_num > 1 then
      raise_application_error (-20001, 'at most one extent is supported');
    end if;
  end loop;
  
  -- delete blocks below HWM
  delete from dump_blocks_gtt where block_id > l_last_used_extent_block_id + l_last_used_block - 1;
  
  -- delete blocks not requested by user
  if upper(p_dump_type) = 'WITHOUT_ROWID' then
    exec( 'delete from dump_blocks_gtt where block_id in (select dbms_rowid.rowid_block_number(rowid) from '||p_table_name||')' );
  end if;
  if upper(p_dump_type) = 'WITH_ROWID' then
    exec ( 'delete from dump_blocks_gtt where block_id not in (select dbms_rowid.rowid_block_number(rowid) from '||p_table_name||')' );
  end if;
  if upper(p_dump_type) like 'BLOCK#%' then
    l_block_num := to_number( substr(p_dump_type, length('BLOCK#')+1) );
    exec ( 'delete from dump_blocks_gtt where block_id != '||(l_block_num+l_last_used_extent_block_id) );
  end if;
  
  -- dump blocks  
  execute immediate 'alter system flush buffer_cache';
       
  l_num := 0;
  for e in (select file_id, block_id from dump_blocks_gtt order by file_id, block_id)
  loop
    sys.dbms_system.ksdwrt(1, '---------------------------------------------------------------------------------------------------------------------------------------------------------------');
    sys.dbms_system.ksdwrt(1, p_message||' - block # '||(e.block_id-l_last_used_extent_block_id)||' from start of extent ');
    sys.dbms_system.ksdwrt(1, '---------------------------------------------------------------------------------------------------------------------------------------------------------------');
    execute immediate 'alter system dump datafile '||e.file_id||' block min '||e.block_id||' block max '||e.block_id ;
    l_num := l_num + 1;
    if l_num > p_max_num_dumped then
      exit;
    end if;
  end loop;
  
end;
/
show errors
--exec dump_blocks ('t', 'BLOCK#1');
--exec dump_blocks ('t', 'BLOCK_RDBA#0x04000101');