-- Supporting code for www.adellera.it/blog
--
-- (c) Alberto Dell'Era, October 2009
-- Tested in 10.2.0.4, 11.1.0.7, 11.2.0.1

set trimspool on
whenever sqlerror continue

drop table test_t1;

alter session set nls_date_format='dd/mm/yyyy hh24:mi:ss';

-- get db version
variable db_version varchar2(30)
declare
  l_dummy varchar2(100);
begin
  dbms_utility.db_version (:db_version, l_dummy);
end;
/

col db_version new_value db_version
select replace ( rtrim(:db_version,'.0'), '.', '_') as db_version from dual;

set echo on

spool mv_logs_&db_version..lst

-- base table test_t1
-- mv log is set to "log everything loggable"
create table test_t1 (x1 int, pk1 int constraint test_t1_pk primary key);

--------------- timestamp-based mv log
create materialized view log on test_t1 with sequence, rowid, primary key (x1) including new values;

col column_name form a15
col data_type form a15
select lower(column_name) as column_name, 
       lower(data_type || '(' || data_length || ')') as data_type from user_tab_cols where table_name = 'MLOG$_TEST_T1' order by column_id;

---- insert, update and delete on all base tables
insert into test_t1 (x1, pk1) values (0, 0);
update test_t1 set x1 = x1 + 1 where pk1 = 0;
delete from test_t1;

col xid$$2 form 99999999999999999999
select xidusn, xidslot, xidsqn, xidusn * power(2,48) + xidslot * power(2,32) + xidsqn as xid$$2 from v$transaction;
commit;

---- inspect mv logs
col m_row$$ form a25
col change_vector$$ form a20
col dmltype$$ form a9
col old_new$$ form a9
col xid$$ form 99999999999999999999
select * from mlog$_test_t1 order by sequence$$;

col xid form 99999999999999999999
select * from all_summap where xid in (select xid$$ from mlog$_test_t1);

drop materialized view log on test_t1;

--------------- exit if not 11gR2
whenever sqlerror exit

--------------- SCN-based mv log
create materialized view log on test_t1 with sequence, rowid, primary key (x1), commit scn including new values;

select lower(column_name) as column_name, 
       lower(data_type || '(' || data_length || ')') as data_type from user_tab_cols where table_name = 'MLOG$_TEST_T1' order by column_id;

---- insert, update and delete on all base tables
insert into test_t1 (x1, pk1) values (0, 0);
update test_t1 set x1 = x1 + 1 where pk1 = 0;
delete from test_t1;

commit;
-- get the commit scn by using ora_rowscn (block cleanout is not delayed for sure)
select distinct ora_rowscn from mlog$_test_t1;

---- inspect mv logs
select * from mlog$_test_t1 order by sequence$$;

select distinct xid$$ from mlog$_test_t1;

col xid form 99999999999999999999
select * from all_summap where xid in (select xid$$ from mlog$_test_t1);

spool off

