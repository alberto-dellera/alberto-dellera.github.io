drop table t purge;

set serveroutput on size 1000000

create table t (x varchar2(10));
create index t_idx on t(x);

insert into t values('000000');
insert into t values('777777');
insert into t values('111111');
insert into t values('666666');
insert into t values('222222');
insert into t values('555555');
insert into t values('333333');
insert into t values('444444');
commit;

alter system flush buffer_cache;


