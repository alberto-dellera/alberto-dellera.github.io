-- Materialized View Fast Refresh Restrictions and ORA-12052 [ID 222843.1]
-- mv logs:
-- Contain all columns from the table referenced in the materialized view. 
-- Specify with ROWID and INCLUDING NEW VALUES.
-- Specify the SEQUENCE clause if the table is expected to have a mix of inserts/direct-loads, deletes, and updates.

-- http://docs.oracle.com/cd/E11882_01/server.112/e25554/basicmv.htm#g1014280 table 9-2

drop materialized view test_mv;
drop table test_master;

alter session set nls_date_format='dd/mm/yyyy hh24:mi:ss';

variable db_version varchar2(30)
declare
  l_dummy varchar2(100);
begin
  dbms_utility.db_version (:db_version, l_dummy);
end;
/

col db_version new_value db_version
select replace ( rtrim(:db_version,'.0'), '.', '_') as db_version from dual;

set echo on

spool mvlog_examples_&db_version..lst

-- base table test_master
create table test_master (whe int, gby int, dat int, not_referenced_in_mvlog int, master_pk int constraint test_master_pk primary key);
insert into test_master (whe, gby, dat, not_referenced_in_mvlog, master_pk) select 0, mod(rownum-1,2), 1, 1, rownum from dual connect by level < 1000;
create materialized view log on test_master with rowid(whe,gby,dat), sequence including new values;

---- inspect mv logs
col M_ROW$$ form a20
col CHANGE_VECTOR$$ form a20
col dmltype$$ form a9
col old_new$$ form a9
col whe form 99999
col gby form 99999
col dat form 99999
col xid$$ form 99999999999999999999999999999

---- insert, update and delete on all base tables
prompt insert:
insert into test_master (whe, gby, dat, not_referenced_in_mvlog, master_pk) values (10, 10, 10, 10, -1);
select sequence$$, m_row$$, dmltype$$, old_new$$, whe, gby, dat from mlog$_test_master order by sequence$$;
delete from mlog$_test_master;
prompt delete:
delete from test_master where master_pk = 1;
select sequence$$, m_row$$, dmltype$$, old_new$$, whe, gby, dat from mlog$_test_master order by sequence$$;
delete from mlog$_test_master;
prompt update:
update test_master set dat=99 where master_pk = -1;
select sequence$$, m_row$$, dmltype$$, old_new$$, whe, gby, dat from mlog$_test_master order by sequence$$;
delete from mlog$_test_master;


spool off

