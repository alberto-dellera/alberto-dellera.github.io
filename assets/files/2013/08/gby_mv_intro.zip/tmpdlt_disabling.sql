define typ=&1.

drop materialized view test_mv;
drop table test_master;

alter session set nls_date_format='dd/mm/yyyy hh24:mi:ss';

variable db_version varchar2(30)
declare
  l_dummy varchar2(100);
begin
  dbms_utility.db_version (:db_version, l_dummy);
end;
/

col db_version new_value db_version
select replace ( rtrim(:db_version,'.0'), '.', '_') as db_version from dual;

set echo on

spool tmpdlt_disabling_&typ._&db_version..lst

-- base table test_master
create table test_master (whe int, gby int, dat int, master_pk int constraint test_master_pk primary key);
insert into test_master (whe, gby, dat, master_pk) select 0, mod(rownum-1,2), 1, rownum from dual connect by level < 1000;
exec dbms_stats.gather_table_stats (user, 'test_master', cascade=>true, method_opt=>'for all columns size 1');
create materialized view log on test_master with rowid(whe,gby,dat) /* NO SEQUENCE */ including new values;
exec dbms_stats.gather_table_stats (user, 'mlog$_test_master', cascade=>true, method_opt=>'for all columns size 1', estimate_percent=>null);
exec dbms_stats.lock_table_stats(user, 'mlog$_test_master');

---- create group_by-only materialized view 
create materialized view test_mv
build immediate
refresh fast on demand
with rowid
as
select gby         as mv_gby, 
       count(*)    as mv_cnt_star,
       count(dat)  as mv_cnt_dat, -- useless for max
       &typ. (dat) as mv_&typ._dat
  from test_master
 -- where whe = 0 -- for fast refresh of all DML, no where clause must be present
 group by gby
;

-- create indexes on ..
exec dbms_stats.gather_table_stats (user, 'test_mv', cascade=>true, method_opt=>'for all columns size 1', estimate_percent=>null);

---- check mv is fast refreshable 
delete from mv_capabilities_table;

exec dbms_mview.explain_mview ( 'test_mv' ); 

set lines 150
col capability_name form a30
col related_text form a10
col msgtxt form a100

select capability_name, possible, related_text, msgtxt from mv_capabilities_table
 where mvowner = user and mvname = 'TEST_MV'
   and capability_name like 'REFRESH%'
 order by capability_name;
  
-- gather stats on mv logs
exec dbms_stats.gather_table_stats (user, 'mlog$_test_master', cascade=>true, method_opt=>'for all columns size 1', force => true);

col sql_id form a13
col sql_text form a100
col tmpdlt form a6

-------------------------- without sequence => NO TMPDLT ----------------------------------
---- insert-only
insert into test_master (whe, gby, dat, master_pk) values (0, 0, 0, -1);
commit;

alter system flush shared_pool;
exec dbms_mview.refresh ( list => 'test_mv', method => 'f', atomic_refresh => true); 
select distinct sql_id,
       decode(instr(sql_text, 'TMPDLT'), 0, 'NO', 'TMPDLT') as tmpdlt,
       sql_text 
 from v$sql where sql_text like '%MV_REFRESH%' and sql_text not like '%sql_id%';

---- delete-only
delete from test_master where rownum=1;
commit;

alter system flush shared_pool;
exec dbms_mview.refresh ( list => 'test_mv', method => 'f', atomic_refresh => true); 
select distinct sql_id,
       decode(instr(sql_text, 'TMPDLT'), 0, 'NO', 'TMPDLT') as tmpdlt,
       sql_text 
 from v$sql where sql_text like '%MV_REFRESH%' and sql_text not like '%sql_id%';

-------------------------- with sequence => TMPDLT ----------------------------------
alter materialized view log on test_master add sequence;
exec dbms_mview.refresh ( list => 'test_mv', method => 'c', atomic_refresh => true);

---- insert-only
insert into test_master (whe, gby, dat, master_pk) values (0, 0, 0, -2);
commit;

alter system flush shared_pool;
exec dbms_mview.refresh ( list => 'test_mv', method => 'f', atomic_refresh => true); 
select distinct sql_id,
       decode(instr(sql_text, 'TMPDLT'), 0, 'NO', 'TMPDLT') as tmpdlt,
       sql_text 
 from v$sql where sql_text like '%MV_REFRESH%' and sql_text not like '%sql_id%';

---- delete-only
delete from test_master where rownum=1;
commit;

alter system flush shared_pool;
exec dbms_mview.refresh ( list => 'test_mv', method => 'f', atomic_refresh => true); 
select distinct sql_id,
       decode(instr(sql_text, 'TMPDLT'), 0, 'NO', 'TMPDLT') as tmpdlt,
       sql_text 
 from v$sql where sql_text like '%MV_REFRESH%' and sql_text not like '%sql_id%';

------------------ "_mav_refresh_opt"=32 => NO TMPDLT ------------------------
alter session set "_mav_refresh_opt"=32;

---- insert-only
insert into test_master (whe, gby, dat, master_pk) values (0, 0, 0, -3);
commit;

alter system flush shared_pool;
exec dbms_mview.refresh ( list => 'test_mv', method => 'f', atomic_refresh => true); 
select distinct sql_id,
       decode(instr(sql_text, 'TMPDLT'), 0, 'NO', 'TMPDLT') as tmpdlt,
       sql_text 
 from v$sql where sql_text like '%MV_REFRESH%' and sql_text not like '%sql_id%';

---- delete-only
delete from test_master where rownum=1;
commit;

alter system flush shared_pool;
exec dbms_mview.refresh ( list => 'test_mv', method => 'f', atomic_refresh => true); 
select distinct sql_id,
       decode(instr(sql_text, 'TMPDLT'), 0, 'NO', 'TMPDLT') as tmpdlt,
       sql_text 
 from v$sql where sql_text like '%MV_REFRESH%' and sql_text not like '%sql_id%';

alter session set "_mav_refresh_opt"=0;

spool off

