089 STATEMENT 89 xsqlid='UPD0jjh98rvh2jfk' xbstmt=86 xs[f=905 l=912] hv=4144055762 sqlid='0jjh98rvh2jfk'
    
/* MV_REFRESH (UPD) */ 
UPDATE "DELLERA"."TEST_MV" SNA$ 
   SET "JINNER"=NULL, "XINNER"=NULL, "PKINNER"=NULL, "TEST_INNER_ROWID"=NULL 
 WHERE "TEST_INNER_ROWID" IN (SELECT /*+ NO_MERGE  HASH_SJ  */ * 
                                FROM (SELECT CHARTOROWID("MAS$"."M_ROW$$") RID$     
                                        FROM "DELLERA"."MLOG$_TEST_INNER" "MAS$"   
                                       WHERE "MAS$".SNAPTIME$$ > :B_ST0 
                                     ) AS OF SNAPSHOT(:B_SCN) MAS$
                              );

    