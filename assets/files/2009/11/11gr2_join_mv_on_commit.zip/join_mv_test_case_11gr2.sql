-- Supporting code for www.adellera.it/blog
--
-- (c) Alberto Dell'Era, October 2009
-- Tested in 11.2.0.1, 11.1.0.7

--define log_based=scn
define log_based=timestamp
define refresh_on=commit
--define refresh_on=demand
 
define sleep_time=60

set trimspool on

drop materialized view test_mv;
drop table test_t1;
drop table test_t2;
drop table test_t3;

alter session set nls_date_format='dd/mm/yyyy hh24:mi:ss';

-- get db version
variable db_version varchar2(30)
declare
  l_dummy varchar2(100);
begin
  dbms_utility.db_version (:db_version, l_dummy);
end;
/

col db_version new_value db_version
select replace ( rtrim(:db_version,'.0'), '.', '_') as db_version from dual;

-- calc commit_scn var
variable timestamp_or_commit_scn varchar2(30)
col timestamp_or_commit_scn new_value timestamp_or_commit_scn
variable with_commit_scn varchar2(30)
col with_commit_scn new_value with_commit_scn
select case when '&log_based.' = 'scn' then 'commit_scn' else 'timestamp' end  as timestamp_or_commit_scn,
       case when '&log_based.' = 'scn' then ', commit scn' end as with_commit_scn
  from dual;

set echo on

define name_str=on_&refresh_on._&timestamp_or_commit_scn._based_&db_version
select '&name_str.' from dual;

spool join_mv_test_case_11gr2_&name_str..lst

---- create base tables
-- jX_Y are the joined columns (X=table number, Y=name of the other table)
-- mv logs are set to "log everything loggable"

-- base table test_t1
create table test_t1 (j1_2 int, x1 int, pk1 int constraint test_t1_pk primary key);
insert into test_t1 (j1_2, x1, pk1) select rownum, 100000 + rownum, rownum from dual connect by level < 100;
create index test_t1_j1_2_idx on test_t1(j1_2);
exec dbms_stats.gather_table_stats (user, 'test_t1', cascade=>true, method_opt=>'for all columns size 1');
create materialized view log on test_t1 with sequence, rowid, primary key &with_commit_scn. (j1_2, x1) including new values;
-- create index mlog_test_t1_idx on mlog$_test_t1 (snaptime$$, old_new$$, dmltype$$, m_row$$) compress 3;
exec dbms_stats.gather_table_stats (user, 'mlog$_test_t1', cascade=>true, method_opt=>'for all columns size 1');

-- base table test_t2
create table test_t2 (j2_1 int, j2_3 int, x2 int, pk2 int constraint test_t2_pk primary key);
insert into test_t2 (j2_1, j2_3, x2, pk2) select rownum, rownum, 100000 + rownum, rownum from dual connect by level <= 100;
create index test_t2_j2_1_idx on test_t2(j2_1);
create index test_t2_j2_3_idx on test_t2(j2_3);
exec dbms_stats.gather_table_stats (user, 'test_t2', cascade=>true, method_opt=>'for all columns size 1');
create materialized view log on test_t2 with sequence, rowid, primary key &with_commit_scn. (j2_1, j2_3, x2) including new values;
-- create index mlog_test_t2_idx on mlog$_test_t2 (snaptime$$, old_new$$, dmltype$$, m_row$$) compress 3;
exec dbms_stats.gather_table_stats (user, 'mlog$_test_t2', cascade=>true, method_opt=>'for all columns size 1');

-- base table test_t3
create table test_t3 (j3_2 int, x3 int, pk3 int constraint test_t3_pk primary key);
insert into test_t3 (j3_2, x3, pk3) select rownum, 100000 + rownum, rownum from dual connect by level <= 100;
create index test_t3_j3_2_idx on test_t3(j3_2);
exec dbms_stats.gather_table_stats (user, 'test_t3', cascade=>true, method_opt=>'for all columns size 1');
create materialized view log on test_t3 with sequence, rowid, primary key &with_commit_scn. (j3_2, x3) including new values;
-- create index mlog_test_t3_idx on mlog$_test_t3 (snaptime$$, old_new$$, dmltype$$, m_row$$) compress 3;
exec dbms_stats.gather_table_stats (user, 'mlog$_test_t3', cascade=>true, method_opt=>'for all columns size 1');

---- create join-only materialized view 
create materialized view test_mv
build immediate
refresh fast on &refresh_on.
as
select test_t1.*, test_t1.rowid as test_t1_rowid,
       test_t2.*, test_t2.rowid as test_t2_rowid,
       test_t3.*, test_t3.rowid as test_t3_rowid
  from test_t1, test_t2, test_t3
 where test_t1.j1_2 = test_t2.j2_1
   and test_t2.j2_3 = test_t3.j3_2
;

-- create indexes on columns tracking the rowid of base tables
create index test_mv_test_t1_rowid on test_mv (test_t1_rowid);
create index test_mv_test_t2_rowid on test_mv (test_t2_rowid);
create index test_mv_test_t3_rowid on test_mv (test_t3_rowid);
exec dbms_stats.gather_table_stats (user, 'test_mv', cascade=>true, method_opt=>'for all columns size 1');

---- check mv is fast refreshable 
delete from mv_capabilities_table;

exec dbms_mview.explain_mview ( 'test_mv'); 

set lines 150
col capability_name form a30
col related_text form a10
col msgtxt form a100

select capability_name, possible, related_text, msgtxt from mv_capabilities_table
 where mvowner = user and mvname = 'TEST_MV'
   and capability_name like 'REFRESH%'
 order by capability_name;
 
-- wait to differentiate timestamps
select sysdate as slightly_after_creation from dual;
exec dbms_lock.sleep (&sleep_time.);
select sysdate as slightly_before_dml from dual;

---- insert, update and delete on all base tables
insert into test_t1 (j1_2, x1, pk1) values (1e9, 1e9, 1e9);
insert into test_t2 (j2_1, j2_3, x2, pk2) values (1e9, 1e9, 1e9, 1e9);
insert into test_t3 (j3_2, x3, pk3) values (1e9, 1e9, 1e9);
update test_t1 set j1_2 = 1e9+99 where pk1 = 1;
update test_t2 set j2_1 = 1e9+99 where pk2 = 1;
update test_t3 set j3_2 = 1e9+99 where pk3 = 1;
update test_t1 set x1 = -x1 where pk1 = 2;
update test_t2 set x2 = -x2 where pk2 = 2;
update test_t3 set x3 = -x3 where pk3 = 2;
delete from test_t1 where pk1 = 3;
delete from test_t2 where pk2 = 3;
delete from test_t3 where pk3 = 3;

---- inspect mv logs
col m_row$$ form a20
col change_vector$$ form a16
col dmltype$$ form a9
col old_new$$ form a9
col xid$$   form 9999999999999999
col xid     form 9999999999999999
col log_xid form 9999999999999999
select * from mlog$_test_t1 order by sequence$$;
select * from mlog$_test_t2 order by sequence$$;
select * from mlog$_test_t3 order by sequence$$;

variable log_xid number 
exec select distinct xid$$ as log_xid into :log_xid from mlog$_test_t3;

---- trace commit
alter session set tracefile_identifier='j_&name_str._comm';
alter session set events '10046 trace name context forever, level 12';
commit;
alter session set events '10046 trace name context off';

-- get the commit scn by using ora_rowscn (block cleanout is not delayed for sure)
select distinct ora_rowscn as commit_scn from test_t3;

select * from all_summap where xid = :log_xid;

--exec dbms_stats.gather_table_stats (user, 'mlog$_test_t1', cascade=>true, method_opt=>'for all columns size 1');
--exec dbms_stats.gather_table_stats (user, 'mlog$_test_t2', cascade=>true, method_opt=>'for all columns size 1');

--select m_row$$, snaptime$$, dmltype$$, old_new$$ from mlog$_test_t1 order by sequence$$;

-- wait to differentiate timestamps
select sysdate as slightly_after_dml from dual;
exec dbms_lock.sleep (&sleep_time.);
select sysdate as slightly_before_refresh from dual;

---- trace fast refresh
exec dbms_application_info.set_module(module_name => 'join_mv_test_case_11gr2',  action_name => 'join_mv_test_case_11gr2');

alter session set tracefile_identifier='j_&name_str._refr';
alter session set events '10046 trace name context forever, level 12';
 
exec dbms_mview.refresh ( list => 'test_mv', method => 'f', atomic_refresh => true); 

alter session set events '10046 trace name context off';

show parameter user_dump_dest;

spool off

exit

